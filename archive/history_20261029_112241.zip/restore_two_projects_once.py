"""Recoverable directory/parameter naming migration; model edits are separate."""
from pathlib import Path
import ctypes as ct,sys,json,shutil,hashlib
from datetime import datetime
ROOT=Path(__file__).resolve().parent.parent
MODEL=ROOT/'model'
OLD=ROOT/'archive'/'model_layout_20261029_104936'/'before'
BACK=ROOT/'archive'/('two_projects_'+datetime.now().strftime('%Y%m%d_%H%M%S'))

def move(src,dst):
    src=src.resolve();dst=dst.resolve()
    assert src.is_relative_to(ROOT.resolve()) and dst.is_relative_to(ROOT.resolve())
    assert src.exists() and not dst.exists()
    shutil.move(str(src),str(dst))

def main():
    assert not (MODEL/'SimSetup_T700').exists()
    BACK.mkdir(parents=True)
    shutil.copytree(MODEL,BACK/'model')
    shutil.copytree(ROOT/'checks',BACK/'checks')
    bundle=ROOT/'data_processed'/'T700_parameter_bundle.mat'
    shutil.copy2(bundle,BACK/bundle.name)
    move(MODEL/'SimSetup',MODEL/'SimSetup_T700')
    shutil.copytree(OLD/'SimSetup',MODEL/'SimSetup')
    # This file belongs to the old T700 staging flow, not the original example.
    move(MODEL/'SimSetup'/'setup_T700_test_boundary.m',BACK/'old_T700_test_boundary.m')
    setup=MODEL/'SimSetup_T700'
    for old,new in [('HPC','Compressor'),('HPT','GGT')]:
        src=setup/f'setup_T700_{old}.m';dst=setup/f'setup_T700_{new}.m'
        move(src,dst)
    paths=list(setup.glob('*.m'))+[MODEL/'T700_initialize.m',MODEL/'T700_plot_parameters.m']+list((ROOT/'checks').glob('*.m'))
    for path in paths:
        s=path.read_text(encoding='utf-8')
        s=s.replace('setup_T700_HPC','setup_T700_Compressor').replace('setup_T700_HPT','setup_T700_GGT')
        s=s.replace('MWS.T700.HPC','MWS.T700.Compressor').replace('MWS.T700.HPT','MWS.T700.GGT')
        s=s.replace('MWS.HPC','MWS.Compressor').replace('MWS.HPT','MWS.GGT')
        s=s.replace('P.HPC','P.Compressor').replace('P.HPT','P.GGT')
        s=s.replace("{'HPC','HPT','FPT'}","{'Compressor','GGT','FPT'}").replace("{'HPT','FPT'}","{'GGT','FPT'}")
        s=s.replace('MWS.Shaft.Jg','MWS.Shaft.J').replace('MWS.Shaft.Jp','MWS.Shaft1.J')
        if path.name=='T700_initialize.m':
            s=s.replace("setupRoot=fullfile(modelDir,'SimSetup');","setupRoot=fullfile(modelDir,'SimSetup_T700');")
            s=s.replace('MWS=setup_T700_Shaft(MWS);','MWS=setup_T700_Shaft(MWS);\nMWS=setup_T700_Shaft1(MWS);')
            s=s.replace("'setup_T700_Burner';'setup_T700_Shaft';'setup_T700_boundary'", "'setup_T700_Burner';'setup_T700_Shaft';'setup_T700_Shaft1';'setup_T700_boundary'")
        if path.name=='setup_T700_Shaft.m':
            s='\n'.join(line for line in s.splitlines() if 'MWS.Shaft1.J' not in line and 'MWS.Shaft.Jload' not in line)+'\n'
        s=s.replace('HPC:','Compressor:').replace('HPT:', 'GGT:')
        path.write_text(s,encoding='utf-8')
    (setup/'setup_T700_Shaft1.m').write_text("function MWS = setup_T700_Shaft1(MWS)\n% Power shaft inertia in slug*ft^2; external load inertia is unspecified.\nMWS.Shaft1.J=0.062;\nMWS.Shaft1.Jload=0;\nend\n",encoding='utf-8')
    # Repack only field names: preserve numeric values, source samples and metadata.
    sys.path.insert(0,str(ROOT/'data_processed'))
    from T700_stage06c_build_outputs import MatFileAPI
    import numpy as np
    api=MatFileAPI()
    cls=api.bind(api.mx,'mxGetClassID',ct.c_int,[ct.c_void_p])
    nf=api.bind(api.mx,'mxGetNumberOfFields',ct.c_int,[ct.c_void_p])
    fn=api.bind(api.mx,'mxGetFieldNameByNumber',ct.c_char_p,[ct.c_void_p,ct.c_int])
    cell=api.bind(api.mx,'mxGetCell',ct.c_void_p,[ct.c_void_p,ct.c_size_t])
    utf=api.bind(api.mx,'mxArrayToUTF8String',ct.c_void_p,[ct.c_void_p])
    free=api.bind(api.mx,'mxFree',None,[ct.c_void_p])
    data=api.bind(api.mx,'mxGetData',ct.c_void_p,[ct.c_void_p])
    def read(p):
        k=cls(p)
        if k==2:return {fn(p,i).decode():read(api.field(p,fn(p,i).decode())) for i in range(nf(p))}
        if k==4:
            q=utf(p)
            try:return ct.string_at(q).decode('utf-8')
            finally:free(q)
        if k==6:return api.read_matrix(p)
        if k==3:
            assert api.rows(p)*api.cols(p)==1
            return bool(ct.cast(data(p),ct.POINTER(ct.c_ubyte))[0])
        if k==1:return [read(cell(p,i)) for i in range(api.rows(p)*api.cols(p))]
        raise TypeError(k)
    h=api.open(str(bundle).encode(),b'r');p=api.get(h,b'T700Parameters')
    try:P=read(p)
    finally:api.destroy(p);api.close(h)
    P['Compressor']=P.pop('HPC');P['GGT']=P.pop('HPT')
    js=P.pop('Shaft');P['Shaft']={'J':js['Jg']};P['Shaft1']={'J':js['Jp']}
    tmp=bundle.with_suffix('.tmp.mat')
    h=api.open(str(tmp).encode(),b'w');p=api.array(P)
    try:assert api.put(h,b'T700Parameters',p)==0
    finally:api.destroy(p);api.close(h)
    h=api.open(str(tmp).encode(),b'r');p=api.get(h,b'T700Parameters')
    try:
        again=read(p)
        def equal(a,b):
            if isinstance(a,dict):return a.keys()==b.keys() and all(equal(v,b[k]) for k,v in a.items())
            if isinstance(a,np.ndarray):return np.array_equal(a,b)
            return a==b
        assert equal(P,again)
    finally:api.destroy(p);api.close(h)
    tmp.replace(bundle)
    (ROOT/'results'/'simsetup_t700'/'T700_two_project_migration.json').write_text(json.dumps(dict(Backup=str(BACK),ParameterValuesUnchanged=True,NativeMATReadbackPassed=True,ModelsEdited=False),indent=2),encoding='utf-8')
    print('Backup:',BACK)
    print('Two SimSetup folders restored; numeric MAT read-back PASS; models not edited in this phase.')

if __name__=='__main__':main()
