"""Only rebind existing component parameters; verify every package XML node."""
from pathlib import Path
import re,xml.etree.ElementTree as E,hashlib,json
ROOT=Path(__file__).resolve().parent.parent
REPORT=ROOT/'results'/'simsetup_t700'/'T700_two_project_migration.json'

def transform(s):
    if s is None:return None
    return s.replace('MWS.HPC.','MWS.Compressor.').replace('MWS.HPT.','MWS.GGT.').replace('MWS.Shaft.Jg','MWS.Shaft.J').replace('MWS.Shaft.Jp','MWS.Shaft1.J').replace('MWS.Noz.','MWS.Nozzle.')

def parts(s):
    result={}
    for m in re.finditer(r'__MWOPC_PART_BEGIN__ ([^\r\n]+)\r?\n(.*?)(?=__MWOPC_PART_BEGIN__|__MWOPC_PACKAGE_END__|\Z)',s,re.S):
        if m[1].endswith(('.xml','.rels')):result[m[1]]=E.fromstring(m[2].strip())
    return result

def compare(a,b,where,changes):
    assert a.tag==b.tag and a.attrib==b.attrib and len(a)==len(b),where
    if a.text!=b.text:
        allowed=b.text==transform(a.text)
        if a.tag=='P' and a.get('Name')=='Eff_M' and a.text=='1' and b.text=='MWS.Burner.Eff':allowed=True
        assert allowed,(where,a.text,b.text)
        changes.append(dict(Location=where,Before=a.text,After=b.text))
    for i,(aa,bb) in enumerate(zip(a,b)):compare(aa,bb,f'{where}/{aa.tag}[{i}]',changes)

def main():
    report=json.loads(REPORT.read_text());backup=Path(report['Backup'])/'model'
    plans=[]
    for name in ('T700_SS','T700_Dyn'):
        path=ROOT/'model'/f'{name}.mdl'
        before=(backup/path.name).read_bytes()
        current=path.read_bytes()
        # If the first namespace edit already ran, accept it only when its hash
        # matches our immediately preceding recorded result.
        if current!=before:
            prior=[v for v in report.get('ModelChanges',[]) if v['Model']==name]
            assert len(prior)==1 and hashlib.sha256(current).hexdigest()==prior[0]['AfterSHA256'],'Model changed since recorded edit; inspect first.'
        old=before.decode('utf-8');new=transform(old)
        pattern=r'(<Block BlockType="Reference" Name="Burner"[^>]*>)(.*?)(</Block>)'
        def burner(m):
            body,count=re.subn(r'(<P Name="Eff_M">)1(</P>)',r'\g<1>MWS.Burner.Eff\g<2>',m[2])
            assert count==1
            return m[1]+body+m[3]
        new,count=re.subn(pattern,burner,new,flags=re.S);assert count==1
        assert not re.search(r'\bMWS\.(HPC|HPT)\b',new)
        aa,bb=parts(old),parts(new);assert aa.keys()==bb.keys()
        changes=[]
        for part in aa:compare(aa[part],bb[part],part,changes)
        assert changes
        plans.append((path,new.encode('utf-8'),dict(Model=name,ParameterChanges=changes,
            XMLPartsChecked=len(aa),TopologyUnchanged=True,LoggingUnchanged=True,
            BeforeSHA256=hashlib.sha256(before).hexdigest(),AfterSHA256=hashlib.sha256(new.encode()).hexdigest())))
    # Validate all planned edits before writing either model.
    for path,data,record in plans:path.write_bytes(data)
    for name in ('Turboshaft_SS','Turboshaft_Dyn'):
        path=ROOT/'model'/f'{name}.mdl'
        assert path.read_bytes()==(backup/path.name).read_bytes()
    report.update(ModelsEdited=True,ModelChanges=[v[2] for v in plans],
        OriginalTurboshaftModelsUnchanged=True,SimulinkCompilationPerformed=False,
        SimulationRun=False,OutputFormatConversionPerformed=False)
    REPORT.write_text(json.dumps(report,indent=2),encoding='utf-8')
    for _,_,record in plans:print(record['Model'],len(record['ParameterChanges']),'parameter texts updated; topology/logging unchanged')

if __name__=='__main__':main()
