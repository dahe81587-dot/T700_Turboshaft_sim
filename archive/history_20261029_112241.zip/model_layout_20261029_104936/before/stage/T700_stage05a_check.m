function report = T700_stage05a_check
modelDir = fileparts(mfilename('fullpath'));
projectDir = fileparts(modelDir);
resultDir = fullfile(projectDir, 'results');
mdl = 'T700_SS';

diary(fullfile(resultDir, 'stage05a_boundary_check.txt'));
stopDiary = onCleanup(@() diary('off'));

assert(bdIsLoaded(mdl), 'Open T700_SS first.');

assert(strcmpi(get_param(mdl, 'FileName'), ...
    fullfile(modelDir, 'T700_SS.mdl')), 'Wrong model file.');

assert(strcmp(get_param(mdl, 'Dirty'), 'off'), ...
    'Save the model first.');

MWS = T700_initialize;

assert(strcmp(get_param([mdl '/BC_W'], ...
    'GotoTag'), 'WfrmIS'));

assert(strcmp(get_param([mdl '/BC_Inlet'], ...
    'ReferenceBlock'), ...
    'Lib_Turbo_FlowPathChar_TMATS/FlowPathChar'));

E = {
    'BC_T2',    'MWS.Boundary.T2_R'
    'BC_P2',    'MWS.Boundary.P2_psia'
    'BC_FAR2',  'MWS.Boundary.FAR2'
    'BC_Wf',    'MWS.Boundary.Wf'
    'BC_Qload', 'MWS.Boundary.Qload'
};

for k = 1:size(E,1)
    actual = strtrim(get_param([mdl '/' E{k,1}], 'Value'));
    assert(strcmp(actual, E{k,2}), ...
        'Wrong value in %s.', E{k,1});
end

assert(strcmp(strtrim(get_param( ...
    [mdl '/BC_LoadSign'], 'Gain')), '-1'));

W = {
    'BC_W',        1, 'BC_Inlet',      1
    'BC_T2',       1, 'BC_Inlet',      2
    'BC_P2',       1, 'BC_Inlet',      3
    'BC_FAR2',     1, 'BC_Inlet',      4
    'BC_Inlet',    1, 'Compressor',    1
    'BC_Inlet',    1, 'InputDis',      1
    'BC_Inlet',    1, 'To Workspace1', 1
    'BC_Wf',       1, 'Burner',        1
    'BC_Qload',    1, 'BC_LoadSign',    1
    'BC_LoadSign', 1, 'Mux3',          1
    'Mux3',        1, 'Shaft1',        1
};

for k = 1:size(W,1)
    checkWire(mdl, W{k,1}, W{k,2}, W{k,3}, W{k,4});
end

report = struct;
report.ModelFile = get_param(mdl, 'FileName');
report.Boundary = MWS.Boundary;
report.ParameterSource = MWS.Project.BoundarySetupFile;
report.ParameterExpressions = E;
report.Connections = W;
report.InterfaceCheckPassed = true;
report.OutletPressureClosed = MWS.Project.OutletPressureClosed;
report.SimulationRun = false;

save(fullfile(resultDir, ...
    'stage05a_boundary_check.mat'), 'report');

fprintf('\nCase ID: %d\n', MWS.Boundary.CaseID);
fprintf('P2: %.6f psia\n', MWS.Boundary.P2_psia);
fprintf('T2: %.6f degR\n', MWS.Boundary.T2_R);
fprintf('Wf: %.10f lbm/s\n', MWS.Boundary.Wf);
fprintf('Qload magnitude: %.6f lbf*ft\n', ...
    MWS.Boundary.Qload);
fprintf('P49 target: %.6f psia\n', MWS.Boundary.P49_psia);

fprintf('Interface checks passed: 1\n');
fprintf('Outlet pressure closed: %d\n', ...
    report.OutletPressureClosed);
fprintf('Simulation run: 0\n');

fprintf('\nSTAGE05A_BOUNDARY_INTERFACE_READY\n');
end

function checkWire(mdl, src, srcPort, dst, dstPort)
S = get_param([mdl '/' src], 'PortHandles');
D = get_param([mdl '/' dst], 'PortHandles');

line = get_param(D.Inport(dstPort), 'Line');

assert(line ~= -1, ...
    'Unconnected input: %s/%d', dst, dstPort);

actualSource = get_param(line, 'SrcPortHandle');

assert(actualSource == S.Outport(srcPort), ...
    'Wrong connection: expected %s/%d -> %s/%d', ...
    src, srcPort, dst, dstPort);
end