function report = T700_stage05b_prepare(action)
if nargin == 0
    action = 'check';
end

modelDir = fileparts(mfilename('fullpath'));
resultDir = fullfile(fileparts(modelDir), 'results');
mdl = 'T700_SS';

assert(bdIsLoaded(mdl), 'Open T700_SS first.');

assert(strcmpi(get_param(mdl, 'FileName'), ...
    fullfile(modelDir, 'T700_SS.mdl')), 'Wrong model file.');

assert(strcmp(get_param(mdl, 'Dirty'), 'off'), ...
    'Save the model first.');

L = legacyNames();

% Validate the complete list before changing any block.
for k = 1:numel(L)
    get_param([mdl '/' L{k}], 'Handle');
end

report = struct;

%% Disable the legacy branches
if strcmpi(action, 'disableLegacy')
    for k = 1:numel(L)
        set_param([mdl '/' L{k}], 'Commented', 'on');
    end

    report.LegacyBlocks = L;

    fprintf('Legacy blocks disabled: %d\n', numel(L));
    fprintf('Save T700_SS, then run the check action.\n');
    return
end

assert(strcmpi(action, 'check'), 'Unknown action.');

%% Check the saved model
diary(fullfile(resultDir, 'stage05b_pressure_check.txt'));
stopDiary = onCleanup(@() diary('off'));

MWS = T700_initialize;

for k = 1:numel(L)
    assert(strcmp(get_param([mdl '/' L{k}], ...
        'Commented'), 'on'), ...
        'Legacy block is active: %s', L{k});
end

active = {
    'BC_Inlet','BC_Wf','BC_Qload','BC_LoadSign', ...
    'Compressor','Burner','GGT','FPT','Shaft','Shaft1', ...
    'Mux1','SS NR Solver w JacobianCalc', ...
    'BC_P49_Select','BC_P49_Target','BC_P49_Mux','BC_P49_Error', ...
    'Log_P49','Log_P49_Error','Goto17','From7'
};

for k = 1:numel(active)
    assert(strcmp(get_param([mdl '/' active{k}], ...
        'Commented'), 'off'), ...
        'Required block is commented: %s', active{k});
end

assert(strcmp(get_param([mdl '/BC_P49_Select'], ...
    'OutputSignals'), 'Pt'));

assert(strcmp(strtrim(get_param([mdl '/BC_P49_Target'], ...
    'Value')), 'MWS.Boundary.P49_psia'));

assert(strcmp(get_param([mdl '/BC_P49_Mux'], ...
    'Inputs'), '2'));

expr = regexprep(get_param([mdl '/BC_P49_Error'], ...
    'Expr'), '\s', '');

assert(strcmp(expr, '(u(1)-u(2))/u(2)'));
assert(MWS.Boundary.P49_psia > 0);

assert(strcmp(get_param([mdl '/Log_P49'], ...
    'VariableName'), 'P49_calc'));

assert(strcmp(get_param([mdl '/Log_P49_Error'], ...
    'VariableName'), 'P49_error'));

mp = get_param([mdl '/Mux1'], 'PortHandles');
assert(numel(mp.Inport) == 6);
assert(numel(MWS.Solve.NR_IC) == 6);

%% Check the remaining residual sources
tags = {
    'Goto17', 'BC_P49_Error'
    'From7',  'BC_P49_Error'
    'From9',  'NFlowEr_ComptoIS'
    'From8',  'NFlowEr_GGT'
    'From15', 'NFlowEr_FPT'
    'From16', 'GGT_Ndot'
    'From10', 'FPT_Ndot'
};

for k = 1:size(tags,1)
    assert(strcmp(get_param([mdl '/' tags{k,1}], ...
        'GotoTag'), tags{k,2}), ...
        'Wrong residual source: %s', tags{k,1});
end

%% Check connections
W = {
    'FPT',           1, 'BC_P49_Select', 1
    'BC_P49_Select', 1, 'BC_P49_Mux',    1
    'BC_P49_Target', 1, 'BC_P49_Mux',    2
    'BC_P49_Mux',    1, 'BC_P49_Error',  1
    'BC_P49_Error',  1, 'Goto17',        1
    'From7',         1, 'Mux1',          1
    'BC_P49_Select', 1, 'Log_P49',       1
    'BC_P49_Error',  1, 'Log_P49_Error', 1
    'From9',         1, 'Mux1',          2
    'From8',         1, 'Mux1',          3
    'From15',        1, 'Mux1',          4
    'From16',        1, 'Mux1',          5
    'From10',        1, 'Mux1',          6
    'Mux1', 1, 'SS NR Solver w JacobianCalc', 2
};

for k = 1:size(W,1)
    checkWire(mdl, W{k,1}, W{k,2}, W{k,3}, W{k,4});
end

%% Save the report
report.ModelFile = get_param(mdl, 'FileName');
report.CaseID = MWS.Boundary.CaseID;
report.P49Target_psia = MWS.Boundary.P49_psia;
report.LegacyBlocks = L;
report.Connections = W;

report.ResidualOrder = {
    'P49_error','Comp_flow_error','GGT_flow_error', ...
    'FPT_flow_error','Ng_dot','Np_dot'
};

report.PressureConstraintConnected = true;
report.NumericalConvergenceChecked = false;
report.SimulationRun = false;

save(fullfile(resultDir, ...
    'stage05b_pressure_check.mat'), 'report');

fprintf('\nCase ID: %d\n', report.CaseID);
fprintf('P49 target: %.6f psia\n', report.P49Target_psia);
fprintf('Matching variables: 6\nResiduals: 6\n');
fprintf('Legacy blocks disabled: %d\n', numel(L));
fprintf('Pressure constraint connected: 1\n');
fprintf('Numerical convergence checked: 0\n');
fprintf('Simulation run: 0\n');

fprintf('\nSTAGE05B_PRESSURE_CONSTRAINT_READY\n');
end

function L = legacyNames
L = {
    'Alt [ft]'; 'Ambient'; 'Inlet'; 'Mach Number [frac]';
    'dTamb [degF]'; 'From4'; 'Goto2'; 'To Workspace'; 'Terminator8';
    'Duct'; 'DuctDis'; 'To Workspace5'; 'Nozzle'; 'From2';
    'Mux2'; 'NozzleDis'; 'Terminator4'; 'Terminator5';
    'Goto7'; 'Goto16';

    sprintf('Bus\nCreator'); 'From12'; 'From17'; 'From18';
    sprintf('Bus\nCreator1'); 'From19'; 'From20'; 'From21'; 'From22';
    sprintf('Bus\nCreator2'); 'From23';

    sprintf('Bus\nCreator3'); 'Goto61'; 'Goto62'; 'Goto63'; 'Goto64';
    'Goto65'; 'Goto66'; 'Goto91'; 'Subsystem'
};
end

function checkWire(mdl, src, srcPort, dst, dstPort)
S = get_param([mdl '/' src], 'PortHandles');
D = get_param([mdl '/' dst], 'PortHandles');

line = get_param(D.Inport(dstPort), 'Line');

assert(line ~= -1, ...
    'Unconnected input: %s/%d', dst, dstPort);

assert(get_param(line, 'SrcPortHandle') == S.Outport(srcPort), ...
    'Wrong connection: expected %s/%d -> %s/%d', ...
    src, srcPort, dst, dstPort);
end
