function T700_stage03_prepare
% Create isolated models and check initialization without simulation.

modelDir = fileparts(mfilename('fullpath'));
projectDir = fileparts(modelDir);
resultDir = fullfile(projectDir, 'results');

assert(isfolder(resultDir), 'Missing results directory.');

addpath(modelDir, '-begin');

diary(fullfile(resultDir, 'stage03_framework_check.txt'));
stopDiary = onCleanup(@() diary('off'));

%% 1. Close only the two legacy model names

legacyNames = {'Turboshaft_SS', 'Turboshaft_Dyn'};

for k = 1:numel(legacyNames)
    name = legacyNames{k};

    if bdIsLoaded(name)
        fprintf('\nLEGACY MODEL: %s\n', ...
            get_param(name, 'FileName'));

        assert(strcmp(get_param(name, 'Dirty'), 'off'), ...
            'Save or resolve unsaved changes to %s first.', name);

        % Remove the obsolete callback in memory only.
        set_param(name, 'CloseFcn', '');
        close_system(name, 0);
    end
end

%% 2. Check repeatable initialization

firstMWS = T700_initialize;
secondMWS = T700_initialize;

assert(isequaln(firstMWS, secondMWS), ...
    'Repeated initialization produced different results.');

%% 3. Create or load the isolated models

sourceNames = {'Turboshaft_SS.mdl', 'Turboshaft_Dyn.mdl'};
modelNames = {'T700_SS', 'T700_Dyn'};
modelFiles = cell(size(modelNames));

for k = 1:numel(modelNames)
    name = modelNames{k};
    sourceFile = fullfile(modelDir, sourceNames{k});
    modelFiles{k} = fullfile(modelDir, [name '.mdl']);

    assert(isfile(sourceFile), 'Missing source: %s', sourceFile);

    if bdIsLoaded(name)
        assert(strcmpi(get_param(name, 'FileName'), modelFiles{k}), ...
            'A model with this name is loaded elsewhere: %s', name);

        assert(strcmp(get_param(name, 'Dirty'), 'off'), ...
            'Save changes to %s before rerunning.', name);

    elseif isfile(modelFiles{k})
        load_system(modelFiles{k});

    else
        assert(isempty(which(name)), ...
            'Name already exists: %s', name);

        new_system(name, 'FromFile', sourceFile, ...
            'ErrorIfShadowed');
    end

    %% 4. Set callbacks for the new models

    set_param(name, ...
        'PreLoadFcn', 'T700_initialize;', ...
        'InitFcn', 'T700_initialize;', ...
        'CloseFcn', '');

    save_system(name, modelFiles{k});

    %% 5. Check closing and reopening

    close_system(name, 0);
    load_system(modelFiles{k});

    assert(strcmpi(get_param(name, 'FileName'), modelFiles{k}), ...
        'Unexpected loaded file: %s', name);

    assert(strcmp(get_param(name, 'PreLoadFcn'), ...
        'T700_initialize;'));

    assert(strcmp(get_param(name, 'InitFcn'), ...
        'T700_initialize;'));

    assert(isempty(get_param(name, 'CloseFcn')));

    fprintf('\nMODEL: %s\nFILE: %s\n', name, ...
        get_param(name, 'FileName'));

    fprintf('PreLoadFcn: %s\n', ...
        get_param(name, 'PreLoadFcn'));

    fprintf('InitFcn: %s\n', ...
        get_param(name, 'InitFcn'));

    fprintf('CloseFcn is empty: %d\n', ...
        isempty(get_param(name, 'CloseFcn')));
end

%% 6. Save the check report

report = struct;
report.InitializationRepeatable = true;
report.ModelFiles = modelFiles;
report.SetupFiles = secondMWS.Project.SetupFiles;
report.ReferenceCases = height(secondMWS.Reference.Input);
report.DynamicTrimReady = secondMWS.Project.DynamicTrimReady;
report.T700ParametersApplied = ...
    secondMWS.Project.T700ParametersApplied;

save(fullfile(resultDir, 'stage03_framework_check.mat'), 'report');

disp(report.SetupFiles);

fprintf('\nReference cases: %d\n', report.ReferenceCases);
fprintf('Initialization repeatable: %d\n', ...
    report.InitializationRepeatable);
fprintf('Dynamic trim ready: %d\n', report.DynamicTrimReady);
fprintf('T700 parameters applied: %d\n', ...
    report.T700ParametersApplied);

fprintf('\nSTAGE03_FRAMEWORK_READY\n');

open_system('T700_SS');
open_system('T700_Dyn');
end