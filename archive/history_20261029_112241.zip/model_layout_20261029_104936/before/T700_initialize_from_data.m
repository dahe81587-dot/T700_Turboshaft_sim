function MWS = T700_initialize_from_data(profile,caseID)
% Entry point for SimSetup_T700; isolated from the legacy initializer.
if nargin<1, profile='ballin_trim1'; end
if nargin<2, caseID=4; end
modelDir = fileparts(mfilename('fullpath'));
setupRoot = fullfile(modelDir,'SimSetup_T700');
addpath(modelDir,'-begin'); addpath(setupRoot,'-begin');
assert(strcmpi(which('T700_setup_all'),fullfile(setupRoot,'T700_setup_all.m')));
MWS = T700_setup_all(profile,caseID);
assignin('base','MWS',MWS);
end
