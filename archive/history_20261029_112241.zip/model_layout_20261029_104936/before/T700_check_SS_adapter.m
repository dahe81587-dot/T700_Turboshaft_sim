function report = T700_check_SS_adapter(profile,caseID)
% Audit the saved adapter, parameter source, bindings, and six solver routes.
% This is not a compilation or numerical-convergence check.

if nargin < 1 || isempty(profile), profile = 'ballin_trim1'; end
if nargin < 2 || isempty(caseID), caseID = 4; end
profile = char(string(profile));
assert(isrow(profile) && ~isempty(regexp(profile,'^[A-Za-z][A-Za-z0-9_]*$','once')), ...
    'Use a simple named parameter profile.');
validateattributes(caseID,{'numeric'},{'scalar','finite','integer','positive'});

modelDir = fileparts(mfilename('fullpath'));
projectDir = fileparts(modelDir);
setupRoot = fullfile(modelDir,'SimSetup_T700');
resultDir = fullfile(projectDir,'results','ss_adapter');
mdl = 'T700_SS_T700Adapter';
modelFile = fullfile(modelDir,[mdl '.mdl']);
assert(bdIsLoaded(mdl),'Run T700_prepare_SS_adapter first.');
assert(samePath(get_param(mdl,'FileName'),modelFile),'Wrong adapter model file loaded.');
assert(strcmp(get_param(mdl,'Dirty'),'off'),'Save the adapter before checking it.');
assert(strcmp(get_param(mdl,'SimulationStatus'),'stopped'),'Stop the adapter before checking it.');
if bdIsLoaded('T700_Dyn')
    assert(strcmp(get_param('T700_Dyn','SimulationStatus'),'stopped'),'Stop T700_Dyn first.');
end
if ~isfolder(resultDir), mkdir(resultDir); end
diary(fullfile(resultDir,'ss_adapter_interface_check.txt'));
stopDiary = onCleanup(@() diary('off'));

entry = fullfile(modelDir,'T700_initialize_from_data.m');
assert(samePath(which('T700_initialize_from_data'),entry),'Wrong T700 parameter entry on the path.');
callback = sprintf('T700_initialize_from_data(''%s'', %d);',profile,caseID);
assert(strcmp(strtrim(get_param(mdl,'PreLoadFcn')),callback),'Wrong adapter PreLoadFcn.');
assert(strcmp(strtrim(get_param(mdl,'InitFcn')),callback),'Wrong adapter InitFcn.');
assert(isempty(strtrim(get_param(mdl,'CloseFcn'))),'The adapter must not inherit a cleanup callback.');
MWS = T700_initialize_from_data(profile,caseID);
files = validateSources(MWS,setupRoot);
validateParameters(MWS);

references = {
    'BC_Inlet','Lib_Turbo_FlowPathChar_TMATS/FlowPathChar'
    'Compressor','Lib_Turbo_Compressor_TMATS/Compressor'
    'Burner','Lib_Turbo_Burner_TMATS/Burner'
    'GGT','Lib_Turbo_Turbine_TMATS/Turbine'
    'FPT','Lib_Turbo_Turbine_TMATS/Turbine'
    'Shaft','Lib_Turbo_Shaft_TMATS/Shaft'
    'Shaft1','Lib_Turbo_Shaft_TMATS/Shaft'
    'SS NR Solver w JacobianCalc','Lib_Solve_SSNRSolverJC_TMATS/SS NR Solver w JacobianCalc'
};
for k = 1:size(references,1)
    block = [mdl '/' references{k,1}];
    assert(strcmp(get_param(block,'ReferenceBlock'),references{k,2}), ...
        'Wrong library component: %s.',references{k,1});
    assert(strcmp(get_param(block,'Commented'),'off'), ...
        'Required component is commented: %s.',references{k,1});
end

bindings = parameterBindings();
for k = 1:size(bindings,1)
    value = get_param([mdl '/' bindings{k,1}],bindings{k,2});
    assert(strcmp(strtrim(value),bindings{k,3}), ...
        'Wrong parameter binding: %s.%s.',bindings{k,1},bindings{k,2});
end
switches = {
    'Compressor','CBLDEN_M','off'
    'Compressor','FBLDEN_M','on'
    'Compressor','C_CBD_M','0'
    'Compressor','iDesign_M','2'
    'Compressor','Scale_M','none'
    'GGT','CFlwEn_M','on'
    'GGT','T_CoolFlwPos_M','1'
    'GGT','ConfigNPSS_M','0'
    'GGT','iDesign_M','2'
    'GGT','Scale_M','none'
    'FPT','CFlwEn_M','off'
    'FPT','T_CoolFlwPos_M','0'
    'FPT','ConfigNPSS_M','0'
    'FPT','iDesign_M','2'
    'FPT','Scale_M','none'
    'Burner','LHVEn_M','on'
};
for k = 1:size(switches,1)
    assert(strcmp(strtrim(get_param([mdl '/' switches{k,1}],switches{k,2})),switches{k,3}), ...
        'Wrong adapter switch: %s.%s.',switches{k,1},switches{k,2});
end
assert(strcmp(strtrim(get_param(mdl,'StopTime')),'MWS.in.SimTime'));
assert(strcmp(strtrim(get_param(mdl,'FixedStep')),'MWS.Solve.T'));
assert(strcmp(strtrim(get_param([mdl '/BC_LoadSign'],'Gain')),'-1'));
assert(strcmp(get_param([mdl '/BC_P49_Select'],'OutputSignals'),'Pt'));
assert(strcmp(get_param([mdl '/BC_P49_Mux'],'Inputs'),'2'));
expr = regexprep(get_param([mdl '/BC_P49_Error'],'Expr'),'\s','');
assert(strcmp(expr,'(u(1)-u(2))/u(2)'));
assert(strcmp(get_param([mdl '/Log_P49'],'VariableName'),'P49_calc'));
assert(strcmp(get_param([mdl '/Log_P49_Error'],'VariableName'),'P49_error'));

selector = [mdl '/T700_CoolingReturn'];
assert(strcmp(get_param(selector,'BlockType'),'Selector'));
assert(strcmp(get_param(selector,'Commented'),'off'));
assert(strcmp(get_param(selector,'NumberOfDimensions'),'1'));
assert(strcmp(get_param(selector,'IndexMode'),'One-based'));
option = get_param(selector,'IndexOptionArray');
index = get_param(selector,'IndexParamArray');
assert(iscell(option) && isscalar(option) && strcmp(option{1},'Index vector (dialog)'));
assert(iscell(index) && isscalar(index) && ...
    strcmp(regexprep(index{1},'\s',''),'11:15'),'Cooling return must select the third five-element stream.');

% Core legacy inlet/nozzle boundaries must remain disabled in this adapter.
legacy = {'Ambient','Inlet','Duct','Nozzle','Goto7','From4','From2'};
for k = 1:numel(legacy)
    assert(strcmp(get_param([mdl '/' legacy{k}],'Commented'),'on'), ...
        'Legacy boundary is active: %s.',legacy{k});
end
required = {'BC_W','BC_T2','BC_P2','BC_FAR2','BC_Wf','BC_Qload','BC_LoadSign', ...
    'BC_P49_Select','BC_P49_Target','BC_P49_Mux','BC_P49_Error','Goto17','From7', ...
    'Mux1','Demux','Log_P49','Log_P49_Error'};
for k = 1:numel(required)
    assert(strcmp(get_param([mdl '/' required{k}],'Commented'),'off'), ...
        'Required route block is commented: %s.',required{k});
end
assert(strcmp(get_param([mdl '/Mux1'],'Inputs'),'6'));
assert(strcmp(get_param([mdl '/Demux'],'Outputs'),'6'));

% From/Goto identity and the producing block/port are checked separately.
tags = {
    'BC_W','WfrmIS'
    'Goto5','WfrmIS'
    'From6','RlinefrmIS'
    'Goto4','RlinefrmIS'
    'From3','GGT_PRfrmIS'
    'Goto3','GGT_PRfrmIS'
    'From11','FPT_PRfrmIS'
    'Goto11','FPT_PRfrmIS'
    'From5','GGT_Nmech'
    'Goto6','GGT_Nmech'
    'From14','FPT_Nmech'
    'Goto13','FPT_Nmech'
    'From7','BC_P49_Error'
    'Goto17','BC_P49_Error'
    'From9','NFlowEr_ComptoIS'
    'Goto9','NFlowEr_ComptoIS'
    'From8','NFlowEr_GGT'
    'Goto8','NFlowEr_GGT'
    'From15','NFlowEr_FPT'
    'Goto14','NFlowEr_FPT'
    'From16','GGT_Ndot'
    'Goto10','GGT_Ndot'
    'From10','FPT_Ndot'
    'Goto12','FPT_Ndot'
};
for k = 1:size(tags,1)
    assert(strcmp(get_param([mdl '/' tags{k,1}],'GotoTag'),tags{k,2}), ...
        'Wrong signal tag: %s.',tags{k,1});
end
gotos = find_system(mdl,'SearchDepth',1,'BlockType','Goto');
allTags = unique(tags(:,2));
for k = 1:numel(allTags)
    count = 0;
    for j = 1:numel(gotos)
        count = count + (strcmp(get_param(gotos{j},'Commented'),'off') && ...
            strcmp(get_param(gotos{j},'GotoTag'),allTags{k}));
    end
    assert(count==1,'An active tag has missing or duplicate Goto blocks: %s.',allTags{k});
end
wires = signalWires();
for k = 1:size(wires,1)
    assertWire(mdl,wires{k,1},wires{k,2},wires{k,3},wires{k,4});
end

report = struct;
report.ModelFile = get_param(mdl,'FileName');
report.SourceModelFile = fullfile(modelDir,'T700_SS.mdl');
report.Profile = profile;
report.CaseID = caseID;
report.ParameterEntry = entry;
report.ParameterSourceRoot = setupRoot;
report.SetupFiles = files;
report.MaskBindings = cell2table(bindings,'VariableNames',{'Block','Parameter','Expression'});
report.Switches = cell2table(switches,'VariableNames',{'Block','Parameter','Value'});
report.SignalWires = wires;
report.UnknownOrder = {'W_in','Rline','PR_GGT','PR_FPT','Ng','Np'};
report.ResidualOrder = {'P49_normalized_error','Compressor_normalized_flow_error', ...
    'GGT_normalized_flow_error','FPT_normalized_flow_error','Ng_dot_rpm_per_s','Np_dot_rpm_per_s'};
report.PressureResidualRoute = {'BC_P49_Error','Goto17','From7','Mux1/1'};
report.CoolingReturnRoute = {'Compressor/2','T700_CoolingReturn[11:15]','GGT/1 at exit'};
report.BleedFractions = MWS.HPC.BleedFractions;
report.BleedScheduleMode = 'Frozen case parameters in the compressor mask; no online schedule';
report.UnknownLowerBounds = MWS.Solve.Lower;
report.UnknownUpperBounds = MWS.Solve.Upper;
report.ResidualTolerances = MWS.Solve.C_Lim;
report.BurnerEfficiencyBound = true;
report.FractionalBleedEnabled = true;
report.GGTExitCoolingEnabled = true;
report.PressureConstraintConnected = true;
report.ParameterSourceChecksPassed = true;
report.NumericDataChecksPassed = true;
report.AdapterInterfacesReady = true;
report.SSInterfacesReady = true;
report.CompileCheckPerformed = false;
report.NumericalConvergenceChecked = false;
report.Converged = false;
report.SimulationRun = false;
report.DynamicTrimReady = false;
save(fullfile(resultDir,'ss_adapter_interface_check.mat'),'report');
fprintf('Profile: %s\nCase ID: %d\n',profile,caseID);
fprintf('Parameter source: %s\n',setupRoot);
fprintf('Unknowns: 6\nResiduals: 6\nFractional bleed streams: 3\nCooling streams returned: 1\n');
fprintf('Adapter interfaces ready: 1\nCompilation checked: 0\nNumerical convergence checked: 0\nSimulation run: 0\n');
fprintf('T700_SS_ADAPTER_INTERFACE_CHECK_PASSED\n');
end

function files = validateSources(MWS,expectedRoot)
assert(isfield(MWS,'Project') && isfield(MWS.Project,'SetupFiles'), ...
    'The parameter entry must provide MWS.Project.SetupFiles for source auditing.');
files = MWS.Project.SetupFiles;
assert(istable(files) && ~isempty(files) && ...
    all(ismember({'Function','File'},files.Properties.VariableNames)), ...
    'SetupFiles must be a nonempty table with Function and File columns.');
if isfield(MWS.Project,'SetupRoot')
    assert(samePath(MWS.Project.SetupRoot,expectedRoot),'Wrong SetupRoot metadata.');
end
for k = 1:height(files)
    name = char(string(files.Function(k)));
    file = char(string(files.File(k)));
    expected = fullfile(expectedRoot,[name '.m']);
    assert(isfile(expected) && samePath(file,expected) && samePath(which(name),expected), ...
        'Wrong setup function source: %s.',name);
end
end

function validateParameters(MWS)
mapCheck(MWS.HPC.NcVec,MWS.HPC.RlineVec,MWS.HPC.WcArray,MWS.HPC.EffArray,'HPC');
assert(isequal(size(MWS.HPC.PRArray),size(MWS.HPC.WcArray)) && ...
    all(isfinite(MWS.HPC.PRArray),'all') && all(MWS.HPC.PRArray>1,'all'));
assert(numel(MWS.HPC.WcMapSurge)==numel(MWS.HPC.PRMapSurge));
for name = {'HPT','FPT'}
    T = MWS.(name{1});
    mapCheck(T.NcVec,T.PRVec,T.WcArray,T.EffArray,name{1});
    assert(all(T.PRVec>1),'Turbine map pressure ratios must be expansion ratios.');
    scalarCheck(T.s_Nc); scalarCheck(T.s_Wc); scalarCheck(T.s_PR); scalarCheck(T.s_eff);
end
scalarCheck(MWS.HPC.s_Nc); scalarCheck(MWS.HPC.s_Wc);
scalarCheck(MWS.HPC.s_PR); scalarCheck(MWS.HPC.s_eff);
validateattributes(MWS.HPC.BleedFractions,{'numeric'},{'column','numel',3,'finite','nonnegative'});
assert(sum(MWS.HPC.BleedFractions)<1);
validateattributes(MWS.HPC.BleedEnthalpyFractions,{'numeric'}, ...
    {'column','numel',3,'finite','>=',0,'<=',1});
validateattributes(MWS.HPC.BleedPressureFractions,{'numeric'}, ...
    {'column','numel',3,'finite','>=',0,'<=',1});
validateattributes(MWS.Burner.Eff,{'numeric'},{'scalar','finite','>',0,'<=',1});
validateattributes(MWS.Burner.dP,{'numeric'},{'scalar','finite','>=',0,'<',1});
scalarCheck(MWS.Burner.LHV); scalarCheck(MWS.Shaft.Jg); scalarCheck(MWS.Shaft.Jp);
scalarCheck(MWS.Boundary.P2_psia); scalarCheck(MWS.Boundary.T2_R);
scalarCheck(MWS.Boundary.P49_psia); scalarCheck(MWS.Boundary.Wf);
validateattributes(MWS.Boundary.Qload,{'numeric'},{'scalar','finite','nonnegative'});
validateattributes(MWS.Solve.NR_IC,{'numeric'},{'column','numel',6,'finite','nonzero'});
validateattributes(MWS.Solve.Lower,{'numeric'},{'column','numel',6,'finite'});
validateattributes(MWS.Solve.Upper,{'numeric'},{'column','numel',6,'finite'});
validateattributes(MWS.Solve.C_Lim,{'numeric'},{'column','numel',6,'finite','positive'});
assert(all(MWS.Solve.Upper>MWS.Solve.Lower));
assert(all(MWS.Solve.NR_IC>=MWS.Solve.Lower & MWS.Solve.NR_IC<=MWS.Solve.Upper));
assert(size(MWS.Solve.J_Calc_Per,2)==6 && ~isempty(MWS.Solve.J_Calc_Per));
assert(all(isfinite(MWS.Solve.J_Calc_Per),'all'));
scalarCheck(MWS.Solve.NR_dx); scalarCheck(MWS.Solve.NR_Jac_Re);
scalarCheck(MWS.Solve.T); scalarCheck(MWS.in.SimTime);
end

function mapCheck(nc,x,wc,eff,name)
assert(isvector(nc) && numel(nc)>=2 && all(isfinite(nc)) && all(diff(nc)>0), ...
    'Invalid %s speed grid.',name);
assert(isvector(x) && numel(x)>=2 && all(isfinite(x)) && all(diff(x)>0), ...
    'Invalid %s second map axis.',name);
expected = [numel(nc),numel(x)];
assert(isequal(size(wc),expected) && isequal(size(eff),expected), ...
    '%s map arrays must have speed rows and second-axis columns.',name);
assert(all(isfinite(wc),'all') && all(wc>0,'all'));
assert(all(isfinite(eff),'all') && all(eff>0 & eff<=1,'all'));
end

function scalarCheck(value)
validateattributes(value,{'numeric'},{'scalar','finite','positive'});
end

function B = parameterBindings
B = {
    'Compressor','Y_C_Map_NcVec_M','MWS.HPC.NcVec'
    'Compressor','X_C_RlineVec_M','MWS.HPC.RlineVec'
    'Compressor','T_C_Map_WcArray_M','MWS.HPC.WcArray'
    'Compressor','T_C_Map_PRArray_M','MWS.HPC.PRArray'
    'Compressor','T_C_Map_EffArray_M','MWS.HPC.EffArray'
    'Compressor','s_C_Nc_M','MWS.HPC.s_Nc'
    'Compressor','s_C_Wc_M','MWS.HPC.s_Wc'
    'Compressor','s_C_PR_M','MWS.HPC.s_PR'
    'Compressor','s_C_Eff_M','MWS.HPC.s_eff'
    'Compressor','X_C_Map_WcSurgeVec_M','MWS.HPC.WcMapSurge'
    'Compressor','T_C_Map_PRSurgeVec_M','MWS.HPC.PRMapSurge'
    'Compressor','C_FBD_M','MWS.HPC.BleedFractions'
    'Compressor','C_BFht_M','MWS.HPC.BleedEnthalpyFractions'
    'Compressor','C_BFPt_M','MWS.HPC.BleedPressureFractions'
    'GGT','Y_T_Map_NcVec_M','MWS.HPT.NcVec'
    'GGT','X_T_Map_PRVec_M','MWS.HPT.PRVec'
    'GGT','T_T_Map_WcArray_M','MWS.HPT.WcArray'
    'GGT','T_T_Map_EffArray_M','MWS.HPT.EffArray'
    'GGT','s_T_Nc_M','MWS.HPT.s_Nc'
    'GGT','s_T_Wc_M','MWS.HPT.s_Wc'
    'GGT','s_T_PR_M','MWS.HPT.s_PR'
    'GGT','s_T_Eff_M','MWS.HPT.s_eff'
    'FPT','Y_T_Map_NcVec_M','MWS.FPT.NcVec'
    'FPT','X_T_Map_PRVec_M','MWS.FPT.PRVec'
    'FPT','T_T_Map_WcArray_M','MWS.FPT.WcArray'
    'FPT','T_T_Map_EffArray_M','MWS.FPT.EffArray'
    'FPT','s_T_Nc_M','MWS.FPT.s_Nc'
    'FPT','s_T_Wc_M','MWS.FPT.s_Wc'
    'FPT','s_T_PR_M','MWS.FPT.s_PR'
    'FPT','s_T_Eff_M','MWS.FPT.s_eff'
    'Burner','LHV_M','MWS.Burner.LHV'
    'Burner','Eff_M','MWS.Burner.Eff'
    'Burner','dPnormBurner_M','MWS.Burner.dP'
    'Shaft','Shaft_Inertia_M','MWS.Shaft.Jg'
    'Shaft1','Shaft_Inertia_M','MWS.Shaft.Jp'
    'BC_T2','Value','MWS.Boundary.T2_R'
    'BC_P2','Value','MWS.Boundary.P2_psia'
    'BC_FAR2','Value','MWS.Boundary.FAR2'
    'BC_Wf','Value','MWS.Boundary.Wf'
    'BC_Qload','Value','MWS.Boundary.Qload'
    'BC_P49_Target','Value','MWS.Boundary.P49_psia'
    'dTamb [degF]1','Value','MWS.Boundary.Pacc_g'
    'dTamb [degF]2','Value','MWS.Boundary.Pacc_p'
    'SS NR Solver w JacobianCalc','SJac_Per_M','MWS.Solve.J_Calc_Per'
    'SS NR Solver w JacobianCalc','SNR_IC_M','MWS.Solve.NR_IC'
    'SS NR Solver w JacobianCalc','SNR_DX_M','MWS.Solve.NR_dx'
    'SS NR Solver w JacobianCalc','SNR_Mx_M','MWS.Solve.Upper'
    'SS NR Solver w JacobianCalc','SNR_Mn_M','MWS.Solve.Lower'
    'SS NR Solver w JacobianCalc','SJacobianAttempts_M','MWS.Solve.NR_Jac_Re'
    'SS NR Solver w JacobianCalc','Cond_Limits_M','MWS.Solve.C_Lim'
};
end

function W = signalWires
W = {
    'BC_W',1,'BC_Inlet',1
    'BC_T2',1,'BC_Inlet',2
    'BC_P2',1,'BC_Inlet',3
    'BC_FAR2',1,'BC_Inlet',4
    'BC_Inlet',1,'Compressor',1
    'BC_Wf',1,'Burner',1
    'Compressor',3,'Burner',2
    'Burner',1,'GGT',2
    'GGT',1,'FPT',2
    'Compressor',2,'T700_CoolingReturn',1
    'T700_CoolingReturn',1,'GGT',1
    'BC_Qload',1,'BC_LoadSign',1
    'BC_LoadSign',1,'Mux3',1
    'Mux3',1,'Shaft1',1
    'Demux',1,'Goto5',1
    'Demux',2,'Goto4',1
    'Demux',3,'Goto3',1
    'Demux',4,'Goto11',1
    'Demux',5,'Goto6',1
    'Demux',6,'Goto13',1
    'From6',1,'Compressor',2
    'From3',1,'GGT',3
    'From11',1,'FPT',3
    'From5',1,'Shaft',3
    'From14',1,'Shaft1',3
    'Shaft',1,'Compressor',3
    'Shaft',1,'GGT',4
    'Shaft1',1,'FPT',4
    'FPT',1,'BC_P49_Select',1
    'BC_P49_Select',1,'BC_P49_Mux',1
    'BC_P49_Target',1,'BC_P49_Mux',2
    'BC_P49_Mux',1,'BC_P49_Error',1
    'BC_P49_Error',1,'Goto17',1
    'BC_P49_Select',1,'Log_P49',1
    'BC_P49_Error',1,'Log_P49_Error',1
    'From7',1,'Mux1',1
    'From9',1,'Mux1',2
    'From8',1,'Mux1',3
    'From15',1,'Mux1',4
    'From16',1,'Mux1',5
    'From10',1,'Mux1',6
    'Compressor',4,'Goto9',1
    'GGT',2,'Goto8',1
    'FPT',2,'Goto14',1
    'Shaft',2,'Goto10',1
    'Shaft1',2,'Goto12',1
    'Mux1',1,'SS NR Solver w JacobianCalc',2
    'SS NR Solver w JacobianCalc',1,'Demux',1
};
end

function assertWire(mdl,src,srcPort,dst,dstPort)
S = get_param([mdl '/' src],'PortHandles');
D = get_param([mdl '/' dst],'PortHandles');
line = get_param(D.Inport(dstPort),'Line');
assert(line ~= -1 && get_param(line,'SrcPortHandle') == S.Outport(srcPort), ...
    'Expected connection %s/%d -> %s/%d.',src,srcPort,dst,dstPort);
end

function yes = samePath(a,b)
yes = strcmpi(strrep(char(a),'/',filesep),strrep(char(b),'/',filesep));
end
