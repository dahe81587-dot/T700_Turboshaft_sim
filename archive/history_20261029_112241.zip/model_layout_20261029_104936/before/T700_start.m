function [MWS,report] = T700_start(profile,caseID)
% One entry for parameter initialization/checking. Does not simulate a model.
if nargin<1, profile='ballin_trim1'; end
if nargin<2, caseID=4; end
MWS=T700_initialize_from_data(profile,caseID);
report=T700_check_parameters(MWS);
resultDir=fullfile(MWS.Project.Root,'results','simsetup_t700');
if ~isfolder(resultDir), mkdir(resultDir); end
save(fullfile(resultDir,'T700_MATLAB_parameter_check.mat'),'report');
assignin('base','MWS',MWS);
fprintf('Loaded %s. Original model callbacks still use the legacy initializer.\n',MWS.Project.SetupRoot);
fprintf('Use T700_prepare_SS_adapter to prepare the separate SS model.\n');
end
