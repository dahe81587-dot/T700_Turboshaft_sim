function fig = T700_plot_parameters(MWS)
% Plot the actual arrays loaded by SimSetup_T700, without running a model.
if nargin<1, MWS=T700_setup_all; end
fig=figure('Name','T700 SimSetup arrays');
tiledlayout(2,2);
nexttile; hold on;
for k=1:numel(MWS.HPC.NcVec)
    plot(MWS.HPC.WcArray(k,:),MWS.HPC.PRArray(k,:), ...
        'DisplayName',sprintf('%.0f%%',100*MWS.HPC.NcVec(k)));
end
xlabel('Wc [lbm/s]'); ylabel('Total pressure ratio'); grid on; legend('Location','eastoutside');
title('HPC: source branches + approximate low-PR plateau');
nexttile; plot(MWS.HPC.WcArray',MWS.HPC.EffArray'); grid on;
xlabel('Wc [lbm/s]'); ylabel('Efficiency'); title('HPC: reference-temperature adapter');
groups={'HPT','FPT'};
for k=1:2
    C=MWS.(groups{k}); nexttile;
    yyaxis left; plot(C.PRVec,C.WcArray(1,:)); ylabel('Wc [lbm/s]');
    yyaxis right; plot(C.PRVec,C.EffArray(1,:)); ylabel('Efficiency');
    xlabel('Total pressure ratio'); grid on;
    title([groups{k} ': replicated Nc rows; frozen reference T/FAR']);
end
end
