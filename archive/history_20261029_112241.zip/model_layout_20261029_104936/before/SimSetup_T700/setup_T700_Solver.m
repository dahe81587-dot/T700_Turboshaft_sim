function MWS = setup_T700_Solver(MWS)
% Six physical unknowns; the last two residual tolerances have rpm/s units.
% Generated from local Ballin data; see README_T700.txt and build audit.

MWS.Solve.C_Lim = [1e-6;1e-6;1e-6;1e-6;0.05;0.05];
MWS.Solve.J_Calc_Per = [0.005*ones(1,6);-0.005*ones(1,6)];
MWS.Solve.NR_IC = MWS.T700.Reference.XSeed(:);
MWS.Solve.NR_dx = 5; % Update limit: 5 percent, not an iteration count.
MWS.Solve.NR_Jac_Re = 20;
MWS.Solve.T = 0.015;
ngBounds = MWS.HPC.s_Nc*[min(MWS.HPC.NcVec);max(MWS.HPC.NcVec)]*sqrt(MWS.Boundary.T2_R/MWS.T700.Constants.Tstd);
MWS.Solve.Lower = [1;min(MWS.HPC.RlineVec);min(MWS.HPT.PRVec);min(MWS.FPT.PRVec);ngBounds(1);5000];
MWS.Solve.Upper = [15;max(MWS.HPC.RlineVec);max(MWS.HPT.PRVec);max(MWS.FPT.PRVec);ngBounds(2);1.2*MWS.T700.Constants.NpDesign];
MWS.Solve.NR_IC = min(MWS.Solve.Upper,max(MWS.Solve.Lower,MWS.Solve.NR_IC));
MWS.Solve.UnknownOrder = {'W_in','Rline','PR_GGT','PR_FPT','Ng','Np'};
MWS.Solve.ResidualOrder = {'P49_error','Compressor_flow','GGT_flow','FPT_flow','Ng_dot_rpm_s','Np_dot_rpm_s'};

end
