function MWS = T700_setup_all(profile,caseID)
% Complete source-traceable parameter initialization; does not open/run a model.
if nargin<1, profile='ballin_trim1'; end
if nargin<2, caseID=4; end
setupRoot = fileparts(mfilename('fullpath'));
projectRoot = fileparts(fileparts(setupRoot));
addpath(setupRoot,'-begin');
MWS = struct;
MWS.engName = 'T700_reference_adapter';
MWS.top_level = fileparts(setupRoot);
MWS = setup_T700_source_functions(MWS);
D = MWS.T700.Experimental;
MWS.Reference.Source.Report = 'NASA-TM-83579, Tables I/II';
MWS.Reference.Source.Engine = 'NASA Lewis experimental test article';
MWS.Reference.Input = array2table(D.InputNumeric,'VariableNames', ...
    {'CaseID','P2_psia','T2_R','P49_psia','Qload_lbf_ft','Wf_lb_h'});
MWS.Reference.Input.Wf_lb_s = MWS.Reference.Input.Wf_lb_h/3600;
MWS.Reference.Reference = array2table(D.MeasuredNumeric,'VariableNames', ...
    {'CaseID','Ng_rpm','Np_rpm','WA2_lb_s','P3_psia','T3_R','T45_R','T49_R'});
MWS = setup_T700_HPC(MWS);
MWS = setup_T700_HPT(MWS);
MWS = setup_T700_FPT(MWS);
MWS = setup_T700_Burner(MWS);
MWS = setup_T700_Shaft(MWS);
MWS = setup_T700_boundary(MWS,profile,caseID);
MWS = setup_T700_Solver(MWS);
MWS.in.SimTime = 1.5; % Time steps are not an asserted NR iteration count.
MWS.Inlet.eRambase = 1; % The SS adapter uses the prescribed inlet gas bus.
MWS.Duct.dP = 0; % The SS adapter bypasses the old exhaust duct/nozzle.
MWS.Input.NRICDyn = nan(4,1);
MWS.Input.Ng0 = NaN;
MWS.Input.Np0 = NaN;
MWS.Input.LP_Shaft = NaN;
MWS.Input.FARin = NaN;
MWS.Project.Root = projectRoot;
MWS.Project.SetupRoot = setupRoot;
MWS.Project.ParametersGenerated = true;
MWS.Project.DataPackageLoaded = true;
MWS.Project.MapAdapterLoaded = true;
MWS.Project.T700ParametersApplied = false; % Requires model-interface audit.
MWS.Project.SSInterfacesReady = false;
MWS.Project.SteadyConvergenceVerified = false;
MWS.Project.ExperimentalValidated = false;
MWS.Project.DynamicTrimReady = false;
MWS.Project.BleedScheduleMode = 'frozen_AppendixB_trim1';
MWS.Project.MapsAreReferenceConditionApproximation = true;
MWS.Project.AllSourcePhenomenaImplementedExactly = false;
names = {'setup_T700_source_functions';'setup_T700_HPC';'setup_T700_HPT'; ...
    'setup_T700_FPT';'setup_T700_Burner';'setup_T700_Shaft'; ...
    'setup_T700_boundary';'setup_T700_Solver'};
files = cell(size(names));
for k=1:numel(names)
    files{k}=which(names{k});
    assert(strcmpi(files{k},fullfile(setupRoot,[names{k} '.m'])),'Wrong setup source: %s',names{k});
end
MWS.Project.SetupFiles = table(names,files,'VariableNames',{'Function','File'});
end
