function MWS = setup_T700_source_functions(MWS)
% Load traceable source-function data and construction metadata.
% Generated from local Ballin data; see README_T700.txt and build audit.

setupRoot = fileparts(mfilename('fullpath'));
S = load(fullfile(setupRoot,'T700_parameter_bundle.mat'),'T700Parameters');
MWS.T700 = S.T700Parameters;

end
