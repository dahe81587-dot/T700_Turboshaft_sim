T700 SimSetup_T700 参数包
更新日期：2026-10-29

本目录用于把 Ballin 的 T700 公开参考部件函数转换为普通 T-MATS 参数接口。
原始数字化数据、T700_SS.mdl、T700_Dyn.mdl、原 SimSetup 和旧初始化入口均保留。
这是一份带有明确近似条件的参考参数包。它尚未通过 NASA Lewis 实验验证。

一、快速开始（MATLAB 命令窗口）

cd('E:\postgraduate\09_Turboshaft\06_simulink\example\T700_validation\model')
[MWS, check] = T700_start;
T700_plot_parameters(MWS);

预期：输出 T700_PARAMETER_CHECKS_PASSED，MWS.HPC/HPT/FPT 中出现新数组。
上面只加载、检查、绘图，不打开模型、不执行稳态求解。

生成并检查独立稳态适配副本：
interface = T700_prepare_SS_adapter('ballin_trim1');

执行参考稳态工况并保存数值证据：
steady = T700_run_SS_adapter('ballin_trim1');

Lewis 第4工况示例：
steady4 = T700_run_SS_adapter('lewis',4);

注意：直接打开原 T700_SS/T700_Dyn 会执行其旧回调 T700_initialize，重新加载旧参数。
新参数包通过 T700_initialize_from_data 进入；适配模型为 T700_SS_T700Adapter。
不要把“原模型打开了”“MWS 中出现新数组”当成新参数已在模型中生效。

二、文件与职责

T700_setup_all.m                按顺序初始化整份 MWS
setup_T700_source_functions.m   读取 T700_parameter_bundle.mat 的源函数和元数据
setup_T700_HPC.m                压气机 Nc、Rline、Wc、PR、效率、引气参数
setup_T700_HPT.m                燃气发生器涡轮 PR、Wc、效率
setup_T700_FPT.m                动力涡轮 PR、Wc、效率
setup_T700_Burner.m             燃烧效率、热值、参考压损
setup_T700_Shaft.m              双轴转动惯量
setup_T700_boundary.m           Ballin 参考工况或 Lewis 实验输入边界
setup_T700_Solver.m             六个求解未知量、初值、边界、残差容差
T700_check_parameters.m         参数维数、数值范围、加载来源检查
T700_plot_parameters.m          当前实际加载数组的绘图入口

上一级 model/T700_start.m 为统一入口；model/T700_prepare_SS_adapter.m 创建副本；
model/T700_check_SS_adapter.m 检查接口；model/T700_run_SS_adapter.m 执行并保存稳态日志。
data_processed 中保留重建与独立方程复算脚本。
results/simsetup_t700 中保留构建审查、特性图、方程复算结果和浏览报告。

三、参数定义与单位

T-MATS 普通格式：温度 degR，压力 psia，流量 lbm/s，比焓 Btu/lbm，
转速 rpm，扭矩 lbf*ft，惯量 slug*ft^2。
Wc = W*sqrt(Tt/518.67)/(Pt/14.695951)
Nc = Nmech/sqrt(Tt/518.67)
NcMap = Nc/s_Nc
PR = 1+s_PR*(PRmap-1)，Wc_calc=s_Wc*WcMap，eff=s_eff*effMap。
数组行对应 NcVec，列对应 RlineVec（压气机）或 PRVec（涡轮）。
HPC 数组11×21；HPT数组7×86；FPT数组7×117。
HPC 的源转速线为65、80、82、85、87、89、92、94、96、98、100%。
源压气机横坐标是静压比 Ps3/P2，转成总压比时使用 P3=Ps3/0.956。
HPC s_Nc=44700；涡轮 s_Nc 用参考入口温度换算，不能照抄压气机44700。

四、必须了解的近似与证据边界

1. Ballin Appendix A 是公开参考模型的函数，不等同于 Lewis 试验发动机的已标定部件图。
   Lewis 输出只在求解后作误差比较，没有用于拟合本参数包。
2. 压气机短支路来自用户所提取的66个点；温升函数来自A2。
   源图的低压比平坦流量段已接入，但其幅值和交点采用每条短支路第一个点近似。
   低压比段和高压边缘代理线均不能支持真实喘振裕度结论。
3. 涡轮缺少真实多转速特性。7行 Nc 数值为重复接口行，不是7条测量转速线。
   入口温度、FAR与动力涡轮排气压力系数在参考条件冻结；不能据此声称完整变工况精度。
4. A9图用 Ps9/P45，Ballin Eq33 写 P49/P45，存在定义冲突。
   当前选择图示/环境压力比解释（figure_ambient），转换时冻结A10排气系数。
   此选择有 Novikov Eq2.40 的环境压力比定义支持，但没有把冲突认定为已证实的原文笔误。
5. A8原始负焓降尾段保留。适配图选 FPT PR>=1.25，不把负值裁剪成伪造的正效率。
6. B1/B2/B3 引气、燃烧室压损与中间引气的焓位置冻结于 Appendix B trim1。
   压气机三路：中间抽取、出口排出、出口冷却返回；第三路在GGT出口注入。
   中间丢弃引气的压升比例0.5是辅助假设；有效引气焓经源T(h)关系转为T-MATS焓基准。
   KH45=0.9623 不直接乘到 T-MATS 绝对比焓上；真实混合与 Ballin 经验式存在差别。
7. A11热惯性函数及所有原始函数已在数据包中保留，尚未接入原动态模型。
   动态模型还需修正边界、双轴初值和控制反馈，再做配平、阶跃与线性化。
8. 此次独立方程复算不执行 MDL/SLX，也不执行 T-MATS MEX。
   MATLAB静态语法检查、MAT文件回读、方程复算、Simulink运行是四种不同的证据。

五、参考工况与求解验收

默认参考：Ballin Appendix B Table B.1 trim1，Ng=41638 rpm，Np=20895 rpm，
T2=518.67 R，P2=14.696 psia，Ps3=176.34 psia（静压），P41=174.28，P45=37.42，
T41=2292 R，T45=1632 R，Wf=476.3 lbm/hr，Qload=229 lbf*ft。
这组参考值用于部件换算和初值，不代表新适配模型必须逐项复现它。

未知量顺序：[W_in,Rline,PR_GGT,PR_FPT,Ng,Np]。
残差顺序：[P49归一化误差,压气机流量误差,GGT流量误差,FPT流量误差,Ng_dot,Np_dot]。
前四个容差1e-6；后两个0.05 rpm/s。NR_dx=5表示每次更新限幅5%，不是5次迭代。
BC_P49_Error -> Goto17 -> From7 -> Mux1/1 的路径在适配副本中保留。
运行入口同时检查 Converged、JacFailed、六残差、特性图范围和质量守恒。
达到停止时间或单独 Converged=1 均不足以判定通过。

六、后续顺序与完成标准

顺序  工作                          完成标准
1     新参数加载与MATLAB参数检查     T700_PARAMETER_CHECKS_PASSED
2     创建SS适配副本/编译/参考求解   六残差、JacFailed、图域、守恒全部通过
3     Lewis标定工况2/4/6比较         明确残差/输出偏差、决定是否有依据调整参数
4     Lewis保留工况3/5验证           固定参数后评估误差；不把保留数据反复调参
5     动态边界/双轴初值/控制接入     稳态导入后无输入扰动时Ng/Np及热状态不漂移
6     燃油/负载小阶跃验证           非线性输出、输入、时间、边界和物理限制记录完整
7     单工作点线性化（必须）         保存x0/u0/y0与A/B/C/D，标明状态/输入/输出/单位；
                                    0.1%~1%小扰动与非线性响应在同一条件下比较，检查步长敏感性
8     多工作点线性化（按需）         仅在局部模型跨工况误差或控制需求有依据时开展

单工作点线性化以前必须先取得有效动态配平。当前没有把原T700_Dyn的旧结构直接线性化，
也没有生成无法由实际运行证明的A/B/C/D矩阵。

自测：为什么Ps3不能直接当P3？为何涡轮7行不代表7条实测转速线？
      怎样区分“参数检查通过”“稳态数值收敛”“实验验证通过”？

来源：sources/A_high_fidelity_real-time_simulation_of_a_small_tu.pdf，Appendix A/B；
      sources/NASA-TM-83579_Hart_Wenzel_1984.pdf，Tables I/II；
      sources/Novikov 2012 - Development of a High-Fidelity Transient Aerothermal Model for a Helicopter Turboshaft Engine.pdf。
