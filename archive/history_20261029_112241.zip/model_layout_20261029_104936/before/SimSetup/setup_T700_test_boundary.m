function MWS = setup_T700_test_boundary(MWS)
% Select one Lewis test case for interface configuration.

caseID = 4;

D = MWS.Reference.Input;
i = find(D.CaseID == caseID);

assert(isscalar(i), ...
    'The selected case is missing or duplicated.');

R = D(i,:);

MWS.Boundary.CaseID = caseID;
MWS.Boundary.Source = 'NASA_Lewis_test_article';

MWS.Boundary.P2_psia = R.P2_psia;
MWS.Boundary.T2_R = R.T2_R;
MWS.Boundary.P49_psia = R.P49_psia;
MWS.Boundary.FAR2 = 0;

MWS.Boundary.Wf = R.Wf_lb_s;
MWS.Boundary.Qload = R.Qload_lbf_ft;

assert(all(isfinite([ ...
    MWS.Boundary.P2_psia, ...
    MWS.Boundary.T2_R, ...
    MWS.Boundary.P49_psia, ...
    MWS.Boundary.Wf, ...
    MWS.Boundary.Qload])));

MWS.Project.BoundaryDataLoaded = true;
MWS.Project.OutletPressureClosed = false;
MWS.Project.BoundarySetupFile = mfilename('fullpath');
end