function report = T700_run_SS_adapter(profile,caseID)
% Prepare/run ONLY the generated SS adapter and retain convergence evidence.
% Passing this check is numerical convergence, not experimental validation.
if nargin<1, profile='ballin_trim1'; end
if nargin<2, caseID=4; end
report=T700_prepare_SS_adapter(profile,caseID);
mdl='T700_SS_T700Adapter';
MWS=T700_initialize_from_data(profile,caseID);
resultDir=fullfile(MWS.Project.Root,'results','ss_adapter');
tag=sprintf('%s_case%d',profile,caseID);
resultFile=fullfile(resultDir,['SS_' tag '.mat']);
report.SimulationAttempted=true;
report.SimulationRun=false;
report.Converged=false;
report.ExperimentalValidated=false;
report.DynamicTrimReady=false;
try
    logVector(mdl,'SS NR Solver w JacobianCalc',1,'T700Check_X');
    logVector(mdl,'Mux1',1,'T700Check_Residual');
    logVector(mdl,sprintf('Bus\nSelector'),1,'T700Check_Converged');
    logVector(mdl,sprintf('Bus\nSelector'),3,'T700Check_JacFailed');
    gasSources={'BC_Inlet',1;'Compressor',3;'Burner',1;'GGT',1;'FPT',1};
    gasNames={'S2','S3','S41','S45','S49'};
    for k=1:numel(gasNames)
        logGas(mdl,gasSources{k,1},gasSources{k,2},['T700Check_' gasNames{k}]);
    end
    save_system(mdl);
    out=sim(mdl,'ReturnWorkspaceOutputs','on');
    report.SimulationRun=true;
    report.CompileCheckPerformed=true;
    report.X=lastRow(out.get('T700Check_X'),6);
    report.Residual=lastRow(out.get('T700Check_Residual'),6);
    report.SolverConverged=logical(lastRow(out.get('T700Check_Converged'),1));
    report.JacFailed=logical(lastRow(out.get('T700Check_JacFailed'),1));
    for k=1:numel(gasNames)
        v=lastRow(out.get(['T700Check_' gasNames{k}]),4);
        report.Stations.(gasNames{k})=struct('W',v(1),'Tt',v(2),'Pt',v(3),'FAR',v(4));
    end
    X=report.X; S=report.Stations;
    coords=[X(2),X(5)/sqrt(S.S2.Tt/518.67)/MWS.HPC.s_Nc; ...
        1+(X(3)-1)/MWS.HPT.s_PR,X(5)/sqrt(S.S41.Tt/518.67)/MWS.HPT.s_Nc; ...
        1+(X(4)-1)/MWS.FPT.s_PR,X(6)/sqrt(S.S45.Tt/518.67)/MWS.FPT.s_Nc];
    groups={'HPC','HPT','FPT'};
    report.MapCoordinates=coords;
    report.AllMapInputsInRange=true;
    for k=1:3
        C=MWS.(groups{k});
        if k==1, axis=C.RlineVec; else, axis=C.PRVec; end
        inside=coords(k,1)>=min(axis) && coords(k,1)<=max(axis) && ...
            coords(k,2)>=min(C.NcVec) && coords(k,2)<=max(C.NcVec);
        report.AllMapInputsInRange=report.AllMapInputsInRange && inside;
    end
    lost=S.S2.W*sum(MWS.HPC.BleedFractions(1:2));
    report.MassBalanceError=S.S49.W-(S.S2.W+MWS.Boundary.Wf-lost);
    report.ResidualTolerances=MWS.Solve.C_Lim(:).';
    report.ResidualsSatisfied=all(abs(report.Residual)<=report.ResidualTolerances);
    report.Converged=report.SolverConverged && ~report.JacFailed && ...
        report.ResidualsSatisfied && report.AllMapInputsInRange && abs(report.MassBalanceError)<1e-6;
    report.NumericalConvergenceChecked=true;
    MWS.Project.SSInterfacesReady=true;
    MWS.Project.T700ParametersApplied=true;
    MWS.Project.SteadyConvergenceVerified=report.Converged;
    assignin('base','MWS',MWS);
    save(resultFile,'report','out','MWS');
    fprintf('Simulink run: 1; residual/map/mass checks passed: %d\n',report.Converged);
    fprintf('Result: %s\n',resultFile);
catch err
    report.ErrorIdentifier=err.identifier;
    report.ErrorMessage=getReport(err,'extended','hyperlinks','off');
    save(resultFile,'report');
    rethrow(err)
end
end

function logVector(mdl,source,port,name)
path=[mdl '/' name];
if getSimulinkBlockHandle(path)==-1
    add_block('simulink/Sinks/To Workspace',path,'VariableName',name, ...
        'SaveFormat','Array','MaxDataPoints','inf','Position',[2600 150 2730 180]);
    sourcePorts=get_param([mdl '/' source],'PortHandles');
    targetPorts=get_param(path,'PortHandles');
    add_line(mdl,sourcePorts.Outport(port),targetPorts.Inport(1),'autorouting','on');
end
end

function logGas(mdl,source,port,name)
selector=[mdl '/' name '_Select'];
mux=[mdl '/' name '_Mux'];
if getSimulinkBlockHandle(selector)==-1
    add_block('simulink/Signal Routing/Bus Selector',selector, ...
        'OutputSignals','W,Tt,Pt,FAR','Position',[2300 200 2320 290]);
    add_block('simulink/Signal Routing/Mux',mux,'Inputs','4','Position',[2440 200 2445 290]);
    src=get_param([mdl '/' source],'PortHandles');
    sel=get_param(selector,'PortHandles'); dst=get_param(mux,'PortHandles');
    add_line(mdl,src.Outport(port),sel.Inport(1),'autorouting','on');
    for j=1:4
        add_line(mdl,sel.Outport(j),dst.Inport(j),'autorouting','on');
    end
end
logVector(mdl,[name '_Mux'],1,name);
end

function row=lastRow(data,n)
assert(isnumeric(data) || islogical(data),'Unexpected To Workspace format.');
assert(~isempty(data) && size(data,2)==n,'Missing or wrong-size SS log.');
row=double(data(end,:));
assert(all(isfinite(row)),'Nonfinite values in SS log.');
end
