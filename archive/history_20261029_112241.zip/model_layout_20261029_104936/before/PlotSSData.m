TMATS.SSplot('GasTurbine_SS_Template',{'s0','s2','s3','s4','s5','s7','s0'});
