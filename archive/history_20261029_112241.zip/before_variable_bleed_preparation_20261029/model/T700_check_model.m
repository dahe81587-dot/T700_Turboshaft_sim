function report = T700_check_model(mdl,MWS)
% Read-only binding audit of a model already opened by the user.
% Does not load/update/save/simulate a model or initialize workspace parameters.
if nargin<1, mdl='T700_SS'; end
if nargin<2
    assert(evalin('base','exist(''MWS'',''var'')')==1,'Run T700_initialize first.');
    MWS=evalin('base','MWS');
end
mdl=char(string(mdl));
assert(bdIsLoaded(mdl),'Open the intended model manually before checking.');
assert(isfield(MWS,'Compressor') && isfield(MWS,'GGT'),'Load T700_initialize before checking a T700 model.');
B={
    'Compressor','Y_C_Map_NcVec_M','MWS.Compressor.NcVec'
    'Compressor','X_C_RlineVec_M','MWS.Compressor.RlineVec'
    'Compressor','T_C_Map_WcArray_M','MWS.Compressor.WcArray'
    'Compressor','T_C_Map_PRArray_M','MWS.Compressor.PRArray'
    'Compressor','T_C_Map_EffArray_M','MWS.Compressor.EffArray'
    'Compressor','s_C_Nc_M','MWS.Compressor.s_Nc'
    'Compressor','s_C_Wc_M','MWS.Compressor.s_Wc'
    'Compressor','s_C_PR_M','MWS.Compressor.s_PR'
    'Compressor','s_C_Eff_M','MWS.Compressor.s_eff'
    'Compressor','X_C_Map_WcSurgeVec_M','MWS.Compressor.WcMapSurge'
    'Compressor','T_C_Map_PRSurgeVec_M','MWS.Compressor.PRMapSurge'
    'GGT','Y_T_Map_NcVec_M','MWS.GGT.NcVec'
    'GGT','X_T_Map_PRVec_M','MWS.GGT.PRVec'
    'GGT','T_T_Map_WcArray_M','MWS.GGT.WcArray'
    'GGT','T_T_Map_EffArray_M','MWS.GGT.EffArray'
    'GGT','s_T_Nc_M','MWS.GGT.s_Nc'
    'GGT','s_T_Wc_M','MWS.GGT.s_Wc'
    'GGT','s_T_PR_M','MWS.GGT.s_PR'
    'GGT','s_T_Eff_M','MWS.GGT.s_eff'
    'FPT','Y_T_Map_NcVec_M','MWS.FPT.NcVec'
    'FPT','X_T_Map_PRVec_M','MWS.FPT.PRVec'
    'FPT','T_T_Map_WcArray_M','MWS.FPT.WcArray'
    'FPT','T_T_Map_EffArray_M','MWS.FPT.EffArray'
    'FPT','s_T_Nc_M','MWS.FPT.s_Nc'
    'FPT','s_T_Wc_M','MWS.FPT.s_Wc'
    'FPT','s_T_PR_M','MWS.FPT.s_PR'
    'FPT','s_T_Eff_M','MWS.FPT.s_eff'
    'Burner','Eff_M','MWS.Burner.Eff'
    'Burner','LHV_M','MWS.Burner.LHV'
    'Burner','dPnormBurner_M','MWS.Burner.dP'
    'Shaft','Shaft_Inertia_M','MWS.Shaft.J'
    'Shaft1','Shaft_Inertia_M','MWS.Shaft1.J'
    'BC_T2','Value','MWS.Boundary.T2_R'
    'BC_P2','Value','MWS.Boundary.P2_psia'
    'BC_Wf','Value','MWS.Boundary.Wf'
    'BC_Qload','Value','MWS.Boundary.Qload'
    'BC_P49_Target','Value','MWS.Boundary.P49_psia'
    'SS NR Solver w JacobianCalc','SJac_Per_M','MWS.Solve.J_Calc_Per'
    'SS NR Solver w JacobianCalc','SNR_IC_M','MWS.Solve.NR_IC'
    'SS NR Solver w JacobianCalc','SNR_DX_M','MWS.Solve.NR_dx'
    'SS NR Solver w JacobianCalc','SNR_Mx_M','MWS.Solve.Upper'
    'SS NR Solver w JacobianCalc','SNR_Mn_M','MWS.Solve.Lower'
    'SS NR Solver w JacobianCalc','SJacobianAttempts_M','MWS.Solve.NR_Jac_Re'
    'SS NR Solver w JacobianCalc','Cond_Limits_M','MWS.Solve.C_Lim'};
actual=cell(size(B,1),1); matches=false(size(B,1),1);
paths=cell(size(B,1),1);
for k=1:size(B,1)
    try
        component=B{k,1}; paths{k}=[mdl '/' component];
        if ismember(component,{'Compressor','GGT','FPT','Burner','Shaft','Shaft1'})
            candidates=find_system(mdl,'FollowLinks','off','LookUnderMasks','none','Name',component);
            keep=false(size(candidates));
            for j=1:numel(candidates)
                ref=get_param(candidates{j},'ReferenceBlock');
                keep(j)=contains(ref,'Lib_Turbo_');
            end
            candidates=candidates(keep);
            assert(isscalar(candidates),'Expected one matching gas-path component.');
            paths{k}=candidates{1};
        end
        actual{k}=get_param(paths{k},B{k,2});
        matches(k)=strcmp(strtrim(actual{k}),B{k,3});
    catch err
        actual{k}=['Unavailable: ' err.message];
    end
end
report.Model=mdl;
report.File=get_param(mdl,'FileName');
report.Profile=MWS.Boundary.Profile;
report.Bindings=cell2table([B,paths,actual,num2cell(matches)], ...
    'VariableNames',{'Block','Parameter','Expected','Path','Actual','Matches'});
report.ListedBindingsMatch=all(matches);
report.PreLoadFcn=get_param(mdl,'PreLoadFcn');
report.InitFcn=get_param(mdl,'InitFcn');
report.ReadOnly=true;
report.CompilationChecked=false;
report.FullTopologyChecked=false;
report.ConvergenceChecked=false;
disp(report.Bindings);
fprintf('Listed bindings match: %d. No model changes, compilation or simulation performed.\n',all(matches));
report.ListedBindingsMatch
end
