function report = T700_check_SS_result(MWS)
% Check an already completed T700 SS run. No initialization/model changes.
% Uses existing Case02Logs, station and component diagnostic workspace logs.
% Assumes ordinary off-design turbine format, zero inlet FAR and rear GGT cooling.
% Residuals are reconstructed from logged diagnostics, not a direct Mux log.
if nargin<1, MWS=workspaceValue('MWS'); end
logs=workspaceValue('Case02Logs');
solver=logs.getElement('Case02_S').Values;
x=lastValue(logs.getElement('Case02_X').Values); x=x(:);
assert(numel(x)==6,'Expected six SS unknowns.');
stationNames={'s2','s3','s4','s5','s6'};
canonical={'S2','S3','S41','S45','S49'};
stationFields={'W','ht','Tt','Pt','FAR'};
S=struct;
for k=1:5
    raw=workspaceValue(stationNames{k});
    S.(canonical{k})=readScalars(raw,stationFields);
end
assert(abs(S.S2.FAR)<1e-12,'This balance check assumes zero inlet FAR.');
D.Compressor=readScalars(workspaceValue('C_Data'), ...
    {'Wcin','WcMap','s_C_Wc','NcMap','PRMap','Nmech','Wbleeds','Pwrout'});
fields={'Wcs1in','WcMap','s_T_Wc','NcMap','PRMap','Nmech','Pwrout'};
D.GGT=readScalars(workspaceValue('GGT_Data'),fields);
D.FPT=readScalars(workspaceValue('FPT_Data'),fields);
assert(all([D.Compressor.Wcin,D.GGT.Wcs1in,D.FPT.Wcs1in]>0));

report=struct;
report.Profile=MWS.Boundary.Profile;
report.Boundary=MWS.Boundary;
report.X=x;
report.UnknownOrder=MWS.Solve.UnknownOrder;
report.Stations=S;
report.Diagnostics=D;
report.SolverConverged=logical(lastValue(getValue(solver,'Converged')));
report.JacFailed=logical(lastValue(getValue(solver,'JacFailed')));
report.ResidualOrder=MWS.Solve.ResidualOrder;
report.ResidualSource='Reconstructed from logged ordinary T-MATS component diagnostics';
report.InputContextMatches=abs(S.S2.Pt-MWS.Boundary.P2_psia)<1e-7 && ...
    abs(S.S2.Tt-MWS.Boundary.T2_R)<1e-6 && ...
    abs((S.S41.W-S.S3.W)-MWS.Boundary.Wf)<1e-7;

% Constants are from installed constants_TMATS.h / Shaft library.
hpToTorque=5252.113;
accessoryHpToTorque=5252.11;
btuPerSecondToHp=1.414853;
torqueC=hpToTorque*D.Compressor.Pwrout/D.Compressor.Nmech;
torqueG=hpToTorque*D.GGT.Pwrout/D.GGT.Nmech;
torqueF=hpToTorque*D.FPT.Pwrout/D.FPT.Nmech;
netNg=torqueC+torqueG-accessoryHpToTorque*MWS.Boundary.Pacc_g/x(5);
netNp=torqueF-MWS.Boundary.Qload-accessoryHpToTorque*MWS.Boundary.Pacc_p/x(6);
r=[(S.S49.Pt-MWS.Boundary.P49_psia)/MWS.Boundary.P49_psia; ...
    (D.Compressor.Wcin-D.Compressor.WcMap*D.Compressor.s_C_Wc)/D.Compressor.Wcin; ...
    (D.GGT.Wcs1in-D.GGT.WcMap*D.GGT.s_T_Wc)/D.GGT.Wcs1in; ...
    (D.FPT.Wcs1in-D.FPT.WcMap*D.FPT.s_T_Wc)/D.FPT.Wcs1in; ...
    60*netNg/(2*pi*MWS.Shaft.J);60*netNp/(2*pi*MWS.Shaft1.J)];
report.Residual=r;
report.ResidualTolerances=MWS.Solve.C_Lim(:);
report.ResidualsPassed=all(abs(r)<=report.ResidualTolerances);
report.ShaftNetTorque_lbf_ft=[netNg;netNp];

% Check the actual requested map coordinates, not a clamped interpolated value.
coords=[x(2),D.Compressor.NcMap;D.GGT.PRMap,D.GGT.NcMap;D.FPT.PRMap,D.FPT.NcMap];
names={'Compressor','GGT','FPT'};
inRange=false(3,1);
for k=1:3
    C=MWS.(names{k});
    if k==1, axis=C.RlineVec; else, axis=C.PRVec; end
    inRange(k)=coords(k,1)>=min(axis) && coords(k,1)<=max(axis) && ...
        coords(k,2)>=min(C.NcVec) && coords(k,2)<=max(C.NcVec);
    report.MapCoordinates.(names{k})=coords(k,:);
    report.MapLimits.(names{k})=[min(axis),max(axis);min(C.NcVec),max(C.NcVec)];
end
report.MapInputsInRange=inRange;
report.MapRangesPassed=all(inRange);

% Three configured bleeds: two discarded, third returns at GGT outlet.
fractions=MWS.Compressor.BleedFractions(:);
hfractions=MWS.Compressor.BleedEnthalpyFractions(:);
assert(numel(fractions)==3 && numel(hfractions)==3);
bleedW=S.S2.W*fractions;
bleedH=S.S2.ht+hfractions*(S.S3.ht-S.S2.ht);
returnedCooling=S.S45.W-S.S41.W;
report.BleedFlowExpected_lbm_s=bleedW;
report.TotalBleedLogged_lbm_s=D.Compressor.Wbleeds;
report.CoolingReturnLogged_lbm_s=returnedCooling;
report.BleedConfigurationPassed=abs(D.Compressor.Wbleeds-sum(bleedW))<1e-6 && ...
    abs(returnedCooling-bleedW(3))<1e-6;
report.MassError_lbm_s=S.S49.W-(S.S2.W+MWS.Boundary.Wf-sum(bleedW(1:2)));
report.MassTolerance_lbm_s=1e-6;
report.MassBalancePassed=abs(report.MassError_lbm_s)<=report.MassTolerance_lbm_s;

% Steady enthalpy balances [Btu/s]; using logged ht preserves gas-table datum.
heatIn=MWS.Boundary.Wf*MWS.Burner.LHV*MWS.Burner.Eff;
power=[D.Compressor.Pwrout;D.GGT.Pwrout;D.FPT.Pwrout]/btuPerSecondToHp;
energy=[S.S2.W*S.S2.ht-S.S3.W*S.S3.ht-sum(bleedW.*bleedH)-power(1); ...
    S.S3.W*S.S3.ht+heatIn-S.S41.W*S.S41.ht; ...
    S.S41.W*S.S41.ht+bleedW(3)*bleedH(3)-S.S45.W*S.S45.ht-power(2); ...
    S.S45.W*S.S45.ht-S.S49.W*S.S49.ht-power(3)];
scale=[max([abs(S.S2.W*S.S2.ht),abs(S.S3.W*S.S3.ht),abs(power(1)),1]); ...
    max([abs(heatIn),abs(S.S41.W*S.S41.ht),1]); ...
    max([abs(S.S41.W*S.S41.ht),abs(power(2)),1]); ...
    max([abs(S.S45.W*S.S45.ht),abs(power(3)),1])];
report.EnergyComponentOrder={'Compressor','Burner','GGT','FPT'};
report.EnergyError_Btu_s=energy;
report.EnergyRelativeError=energy./scale;
report.EnergyRelativeTolerance=1e-3; % Numerical screening, not experimental accuracy.
report.EnergyBalancePassed=all(abs(report.EnergyRelativeError)<=report.EnergyRelativeTolerance);
report.AllChecksPassed=report.SolverConverged && ~report.JacFailed && ...
    report.InputContextMatches && report.ResidualsPassed && report.MapRangesPassed && ...
    report.BleedConfigurationPassed && report.MassBalancePassed && report.EnergyBalancePassed;
report.ExperimentalValidationPassed=false;
report.DynamicTrimVerified=false;
report.LowPRCompressorRegionUsed=x(2)>2;
report.FixedParameterReferenceTrim=1;
report.SourcePressureRatioAmbiguityResolved=false;
% Table B.1 comparison is source-model consistency, not experimental validation.
if startsWith(lower(report.Profile),'ballin_trim') && isfield(MWS.Reference,'Ballin')
    ref=MWS.Reference.Ballin(MWS.Reference.Ballin.TrimID==MWS.Boundary.TrimID,:);
    comparison.Quantities={'Ng','Np','Ps3','P41','P45','T41','T45','Power'};
    comparison.Units={'rpm','rpm','psia','psia','psia','degR','degR','hp'};
    comparison.Reference=[ref.Ng_rpm;ref.Np_rpm;ref.Ps3_psia;ref.P41_psia; ...
        ref.P45_psia;ref.T41_R;ref.T45_R;ref.Power_hp];
    comparison.Simulation=[x(5);x(6);S.S3.Pt*MWS.T700.Constants.Kps3; ...
        S.S41.Pt;S.S45.Pt;S.S41.Tt;S.S45.Tt;D.FPT.Pwrout];
    comparison.ErrorPercent=100*(comparison.Simulation-comparison.Reference)./comparison.Reference;
    comparison.Source='NASA-TM-100991 Appendix B Table B.1; PDF67 printed53';
    comparison.TrimID=MWS.Boundary.TrimID;
    comparison.Ps3Convention='Ps3=Kps3*logged total pressure Pt3';
    comparison.IndependentExperimentalValidation=false;
    report.ReferenceComparison=comparison;
    disp(table(comparison.Quantities(:),comparison.Units(:),comparison.Reference, ...
        comparison.Simulation,comparison.ErrorPercent, ...
        'VariableNames',{'Quantity','Unit','Reference','Simulation','ErrorPercent'}));
end
disp(table(report.ResidualOrder(:),r,report.ResidualTolerances, ...
    abs(r)<=report.ResidualTolerances,'VariableNames',{'Residual','Value','Tolerance','Passed'}));
checks={'InputContextMatches','ResidualsPassed','MapRangesPassed', ...
    'BleedConfigurationPassed','MassBalancePassed','EnergyBalancePassed'};
for k=1:numel(checks), fprintf('%s: %d\n',checks{k},report.(checks{k})); end
fprintf('Mass balance error [lbm/s]: %.6g\n',report.MassError_lbm_s);
outDir=fullfile(MWS.Project.Root,'results','simsetup_t700');
if ~isfolder(outDir), mkdir(outDir); end
resultFile=fullfile(outDir,'T700_SS_result_check.mat');
runs=struct;
if isfile(resultFile)
    previousResults=load(resultFile);
    if isfield(previousResults,'runs')
        runs=previousResults.runs;
    elseif isfield(previousResults,'report') && isfield(previousResults.report,'Profile')
        old=previousResults.report;
        if strcmpi(old.Profile,'lewis')
            oldKey=sprintf('lewis_case%d',old.Boundary.CaseID);
        else
            oldKey=old.Profile;
        end
        runs.(matlab.lang.makeValidName(oldKey))=old;
    end
end
if strcmpi(report.Profile,'lewis')
    key=sprintf('lewis_case%d',report.Boundary.CaseID);
else
    key=report.Profile;
end
runs.(matlab.lang.makeValidName(key))=report;
sourceData=load(MWS.Project.ParameterBundle,'T700Parameters');
sourceConsistency=checkSourceRelations(runs,sourceData.T700Parameters.SourceFunctions);
adaptationAudit=checkAdaptation(runs,sourceData.T700Parameters);
% Keep dated offline source-replay evidence, with its own baseline fingerprints.
if isfile(resultFile)
    save(resultFile,'report','runs','sourceConsistency','adaptationAudit','-append');
else
    save(resultFile,'report','runs','sourceConsistency','adaptationAudit');
end
report.AllChecksPassed
end

function audit=checkAdaptation(runs,P)
% Read-only diagnosis. Source schedules and damping are NOT applied to a model.
% Ballin Eq12-16,29-30,41 / Table A.1. Current topology has rear cooling.
F=P.SourceFunctions; C=P.Constants;
audit.Source='NASA-TM-100991 Eq12-16,24-30,41 and Table A.1';
audit.ModelOrParameterChangesApplied=false;
audit.IndependentExperimentalValidation=false;
audit.NativeMEXExecuted=exist('T2HM_TMATS','file')==3 && exist('H2TM_TMATS','file')==3;
audit.Bleeds.Columns={'TrimID','NGc_percent','B1_FrozenTrim1','B1_SourceAtActualNg', ...
    'B1_SourceAtReferenceNg','Stage4FractionConfigured','Stage4FractionSource', ...
    'AdditionalStage4BleedAtFixedInlet_lbm_s','CoolingConfigured_lbm_s','CoolingSource_lbm_s'};
audit.Bleeds.Values=zeros(0,numel(audit.Bleeds.Columns));
audit.Damping.Kdamp_lbf_ft_s_rad=.06854;
audit.Damping.NpDesign_rpm=20900;
audit.Damping.Columns={'TrimID','Np_Current_rpm','SourceDampingTorque_lbf_ft', ...
    'SourceDampingPowerAtCurrent_hp','FrozenGasPathPredictedNp_rpm', ...
    'PredictedNpErrorPercent','PredictedLoadPower_hp'};
audit.Damping.Values=zeros(0,numel(audit.Damping.Columns));
audit.Damping.Interpretation=['Frozen logged gas path and FPT gas power; ' ...
    'algebraic sensitivity only, not a Simulink run. Source damping is signed about NpDesign.'];
audit.Thermal.Columns={'TrimID','T45_Replay_R','T45_Logged_R','ReplayMinusLogged_R', ...
    'T45_NativeWithSourceDh_R','T45_Ballin_R', ...
    'NativeThermoMixContribution_R','MapDhContribution_R'};
audit.Thermal.Values=zeros(0,numel(audit.Thermal.Columns));
audit.Thermal.EvaluationMethod='Unavailable: native thermodynamic MEX functions are not on the path';
if audit.NativeMEXExecuted
    audit.Thermal.EvaluationMethod='Native T2HM_TMATS / H2TM_TMATS MEX calls';
end
audit.Thermal.Interpretation=['NativeWithSourceDh retains recorded mass flows, FAR and ' ...
    'compressor-outlet cooling enthalpy. Contributions are fixed-state diagnostics.'];
keys=fieldnames(runs);
for k=1:numel(keys)
    r=runs.(keys{k});
    if ~startsWith(lower(r.Profile),'ballin_trim') || ~isfield(r,'ReferenceComparison'), continue; end
    S=r.Stations; ref=r.ReferenceComparison.Reference(:); trim=r.Boundary.TrimID;
    ngc=100*r.X(5)/sqrt(S.S2.Tt/C.Tstd)/C.NgDesign;
    ngcRef=100*ref(1)/sqrt(S.S2.Tt/C.Tstd)/C.NgDesign;
    b1=lookup(F.A03,ngc); b2=lookup(F.A04,r.Diagnostics.Compressor.Wcin);
    b3=lookup(F.A05,r.Diagnostics.Compressor.Wcin);
    configured=r.BleedFlowExpected_lbm_s(1)/S.S2.W;
    wcool=S.S45.W-S.S41.W;
    audit.Bleeds.Values(end+1,:)=[trim,ngc,P.Reference.B1,b1,lookup(F.A03,ngcRef), ...
        configured,b1+b2,S.S2.W*(b1+b2-configured),wcool,S.S2.W*b3*C.Kbl];
    kd=audit.Damping.Kdamp_lbf_ft_s_rad*2*pi/60;
    n=r.X(6); power=r.Diagnostics.FPT.Pwrout; q=r.Boundary.Qload;
    qd=kd*(n-audit.Damping.NpDesign_rpm);
    a=q-kd*audit.Damping.NpDesign_rpm;
    predicted=2*power*5252.113/(a+sqrt(a^2+4*kd*power*5252.113));
    audit.Damping.Values(end+1,:)=[trim,n,qd,qd*n/5252.113,predicted, ...
        100*(predicted/ref(2)-1),q*predicted/5252.113];
    if audit.NativeMEXExecuted
        % Compare temperatures; never multiply Ballin KH45 into native absolute h.
        hin=T2HM_TMATS(S.S41.Tt,S.S41.FAR);
        hc=T2HM_TMATS(S.S3.Tt,0);
        dhModel=r.Diagnostics.GGT.Pwrout/1.414853/S.S41.W;
        dhSource=(.0018326*S.S41.Tt+.0856)*lookup(F.A07,S.S45.Pt/S.S41.Pt);
        hReplay=(S.S41.W*(hin-dhModel)+wcool*hc)/S.S45.W;
        hSource=(S.S41.W*(hin-dhSource)+wcool*hc)/S.S45.W;
        tReplay=H2TM_TMATS(hReplay,S.S45.FAR);
        tNative=H2TM_TMATS(hSource,S.S45.FAR);
        tBallin=3.519*.9623*(.301*S.S41.Tt-86.905-dhSource)+179.1;
        audit.Thermal.Values(end+1,:)=[trim,tReplay,S.S45.Tt,tReplay-S.S45.Tt, ...
            tNative,tBallin,tNative-tBallin,S.S45.Tt-tNative];
    end
end
fprintf('Source schedule / thermal audit (diagnostic only):\n');
disp(array2table(audit.Bleeds.Values,'VariableNames',audit.Bleeds.Columns));
disp(array2table(audit.Damping.Values,'VariableNames',audit.Damping.Columns));
if audit.NativeMEXExecuted
    disp(array2table(audit.Thermal.Values,'VariableNames',audit.Thermal.Columns));
else
    fprintf('Thermal replay skipped: T2HM_TMATS / H2TM_TMATS MEX is not on the MATLAB path.\n');
end
end

function result=checkSourceRelations(runs,functions)
% Reference-relationship audit only; does not alter any simulated result.
% Table A.1: H41=.301*T41-86.905; H45=.9623*H44; T45=3.519*H45+179.1.
result.Columns={'TrimID','GGT_dH_ErrorPercent','FPT_dH_ErrorPercent', ...
    'T45_SourceAtActualUpstream_R','T45_Model_R','ModelMinusSourceT45_R', ...
    'T45_SourceAtReference_R','T45_Table_R','SourceMinusTableT45_R', ...
    'Power_SourceAtReference_hp','Power_Table_hp','SourcePowerErrorPercent'};
result.Values=zeros(0,numel(result.Columns));
result.Interpretation='A9 figure ambient ratio; A10 Eq38; definition conflict remains unresolved';
result.IndependentExperimentalValidation=false;
keys=fieldnames(runs);
for k=1:numel(keys)
    r=runs.(keys{k});
    if ~startsWith(lower(r.Profile),'ballin_trim') || ~isfield(r,'ReferenceComparison'), continue; end
    S=r.Stations; D=r.Diagnostics; ref=r.ReferenceComparison.Reference(:);
    a7=S.S45.Pt/S.S41.Pt;
    a8=S.S49.Pt/S.S45.Pt;
    sourceGT=(.0018326*S.S41.Tt+.0856)*lookup(functions.A07,a7);
    sourcePT=(.0018326*S.S45.Tt+.0856)*lookup(functions.A08,a8);
    modelGT=D.GGT.Pwrout/1.414853/S.S41.W;
    modelPT=D.FPT.Pwrout/1.414853/S.S45.W;
    actualSourceT45=3.519*.9623*(.301*S.S41.Tt-86.905-sourceGT)+179.1;
    refGT=(.0018326*ref(6)+.0856)*lookup(functions.A07,ref(5)/ref(4));
    refSourceT45=3.519*.9623*(.301*ref(6)-86.905-refGT)+179.1;
    refTheta45=.0018326*ref(7)+.0856;
    refDh=refTheta45*lookup(functions.A08,r.Boundary.P49_psia/ref(5));
    refW=lookup(functions.A09,r.Boundary.P2_psia/ref(5))*ref(5)/sqrt(refTheta45);
    refPower=refW*refDh*1.414853;
    row=[r.ReferenceComparison.TrimID,100*(modelGT/sourceGT-1), ...
        100*(modelPT/sourcePT-1),actualSourceT45,S.S45.Tt,S.S45.Tt-actualSourceT45, ...
        refSourceT45,ref(7),refSourceT45-ref(7),refPower,ref(8),100*(refPower/ref(8)-1)];
    result.Values(end+1,:)=row;
end
end

function y=lookup(curve,x)
y=interp1(curve.X(:),curve.Y(:),x,'linear',NaN);
assert(isfinite(y),'Reference comparison is outside the digitized source domain.');
end

function value=workspaceValue(name)
assert(evalin('base',sprintf('exist(''%s'',''var'')',name))==1, ...
    'Missing %s. Run the intended T700_SS simulation first.',name);
value=evalin('base',name);
end

function result=readScalars(raw,fields)
result=struct;
for k=1:numel(fields)
    value=lastValue(getValue(raw,fields{k}));
    assert(isscalar(value),'Expected scalar diagnostic %s.',fields{k});
    result.(fields{k})=value;
end
end

function value=getValue(raw,name)
assert(isstruct(raw) && isfield(raw,name),'Missing logged field %s.',name);
value=raw.(name);
end

function value=lastValue(raw)
if isa(raw,'timeseries')
    assert(~isempty(raw.Time),'Empty timeseries.');
    value=getdatasamples(raw,numel(raw.Time));
elseif isnumeric(raw) || islogical(raw)
    if isvector(raw), value=raw; else, value=raw(end,:); end
else
    error('Unsupported logged value type: %s.',class(raw));
end
value=double(value(:));
assert(~isempty(value) && all(isfinite(value)),'Empty or nonfinite logged result.');
end
