"""One-time, recoverable layout migration. Does not edit any model file."""
from pathlib import Path
import hashlib,shutil,json
from datetime import datetime

ROOT=Path(__file__).resolve().parent.parent
MODEL=ROOT/'model'
ARCHIVE=ROOT/'archive'/('model_layout_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def move(src,dst):
    src=src.resolve();dst=dst.resolve()
    assert src.is_relative_to(ROOT.resolve()) and dst.is_relative_to(ROOT.resolve())
    assert src.exists() and not dst.exists(),(src,dst)
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(src),str(dst))

def main():
    assert (MODEL/'SimSetup_T700'/'T700_setup_all.m').is_file()
    before={p.name:digest(p) for p in MODEL.glob('*.mdl')}
    ARCHIVE.mkdir(parents=True)
    shutil.copytree(MODEL,ARCHIVE/'before')
    for p in MODEL.rglob('*'):
        if p.is_file():assert digest(p)==digest(ARCHIVE/'before'/p.relative_to(MODEL))
    oldall=(MODEL/'SimSetup_T700'/'T700_setup_all.m').read_text(encoding='utf-8')
    solver=(MODEL/'SimSetup_T700'/'setup_T700_Solver.m').read_text(encoding='utf-8')
    solverbody=solver[solver.index('MWS.Solve.C_Lim'):solver.rfind('end')]
    check=(MODEL/'SimSetup_T700'/'T700_check_parameters.m').read_text(encoding='utf-8')
    plot=(MODEL/'SimSetup_T700'/'T700_plot_parameters.m').read_text(encoding='utf-8')
    move(MODEL/'SimSetup',ARCHIVE/'retired'/'SimSetup')
    move(MODEL/'SimSetup_T700',MODEL/'SimSetup')
    setup=MODEL/'SimSetup'
    for name in ('T700_initialize_from_data.m','T700_start.m','T700_prepare_SS_adapter.m',
                 'T700_check_SS_adapter.m','T700_run_SS_adapter.m','Turboshaft_SS_setup_everything.m',
                 'Turboshaft_SS_Example_cleanup.m','T700_initialize.m'):
        move(MODEL/name,ARCHIVE/'retired'/name)
    if (MODEL/'stage').exists():move(MODEL/'stage',ARCHIVE/'retired'/'stage')
    move(setup/'T700_parameter_bundle.mat',ROOT/'data_processed'/'T700_parameter_bundle.mat')
    for name in ('T700_setup_all.m','setup_T700_source_functions.m','setup_T700_Solver.m','README_T700.txt'):
        move(setup/name,ARCHIVE/'retired'/'SimSetup_T700'/name)
    move(setup/'T700_check_parameters.m',ROOT/'checks'/'T700_check_parameters.m')
    move(setup/'T700_plot_parameters.m',MODEL/'T700_plot_parameters.m')
    check=check.replace('if nargin<1, MWS = T700_setup_all; end',
        "if nargin<1\n    assert(evalin('base','exist(''MWS'',''var'')')==1,'Run T700_initialize first.');\n    MWS=evalin('base','MWS');\nend")
    (ROOT/'checks'/'T700_check_parameters.m').write_text(check,encoding='utf-8')
    plot=plot.replace('if nargin<1, MWS=T700_setup_all; end',
        "if nargin<1\n    assert(evalin('base','exist(''MWS'',''var'')')==1,'Run T700_initialize first.');\n    MWS=evalin('base','MWS');\nend")
    (MODEL/'T700_plot_parameters.m').write_text(plot,encoding='utf-8')
    flags=oldall[oldall.index('MWS.in.SimTime'):oldall.index('names = {')]
    flags=flags.replace('MWS.Project.Root = projectRoot;', 'MWS.Project.Root = projectRoot;')
    init="""function MWS = T700_initialize(profile,caseID)
% Unified workspace initialization. Does not open, edit, or run a model.
% T700_initialize                 -> Ballin reference trim 1
% T700_initialize('lewis',4)      -> Lewis experimental input case 4
if nargin<1 || isempty(profile), profile='ballin_trim1'; end
if nargin<2, caseID=[]; end
profile=char(string(profile));
if strcmpi(profile,'lewis')
    validateattributes(caseID,{'numeric'},{'scalar','integer','>=',1,'<=',6});
elseif strcmpi(profile,'ballin_trim1')
    assert(isempty(caseID),'Ballin trim1 does not use a Lewis CaseID. Omit the second argument.');
else
    error('Profile must be ballin_trim1 or lewis.');
end
modelDir=fileparts(mfilename('fullpath'));
projectRoot=fileparts(modelDir);
setupRoot=fullfile(modelDir,'SimSetup');
addpath(modelDir,'-begin');
addpath(setupRoot,'-begin');
addpath(fullfile(projectRoot,'checks'),'-begin');
dataFile=fullfile(projectRoot,'data_processed','T700_parameter_bundle.mat');
S=load(dataFile,'T700Parameters');
P=S.T700Parameters;
MWS=struct;
MWS.engName='T700_reference_adapter';
MWS.top_level=modelDir;
% Only runtime constants/reference seed and component metadata enter MWS.
% Original source samples and measured experimental outputs stay in the MAT file.
MWS.T700.Constants=P.Constants;
MWS.T700.Reference=P.Reference;
MWS.T700.HPC.MetadataJSON=P.HPC.MetadataJSON;
MWS.T700.HPT.MetadataJSON=P.HPT.MetadataJSON;
MWS.T700.FPT.MetadataJSON=P.FPT.MetadataJSON;
MWS.Reference.Source.Report='NASA-TM-83579, Table I';
MWS.Reference.Source.Engine='NASA Lewis experimental test article';
MWS.Reference.Input=array2table(P.Experimental.InputNumeric,'VariableNames', ...
    {'CaseID','P2_psia','T2_R','P49_psia','Qload_lbf_ft','Wf_lb_h'});
MWS.Reference.Input.Wf_lb_s=MWS.Reference.Input.Wf_lb_h/3600;
MWS=setup_T700_HPC(MWS);
MWS=setup_T700_HPT(MWS);
MWS=setup_T700_FPT(MWS);
MWS=setup_T700_Burner(MWS);
MWS=setup_T700_Shaft(MWS);
MWS=setup_T700_boundary(MWS,profile,caseID);
% Solver settings belong to the initialization entry, not a component file.
"""+solverbody+'\n'+flags+"""
names={'setup_T700_HPC';'setup_T700_HPT';'setup_T700_FPT'; ...
    'setup_T700_Burner';'setup_T700_Shaft';'setup_T700_boundary'};
files=cell(size(names));
for k=1:numel(names)
    files{k}=which(names{k});
    assert(strcmpi(files{k},fullfile(setupRoot,[names{k} '.m'])),'Wrong setup source: %s',names{k});
end
MWS.Project.SetupFiles=table(names,files,'VariableNames',{'Function','File'});
MWS.Project.ParameterBundle=dataFile;
MWS.Project.ExperimentalMeasurementsLoaded=false;
assert(strcmpi(which('T700_check_parameters'),fullfile(projectRoot,'checks','T700_check_parameters.m')));
T700_check_parameters(MWS);
MWS.Project.ParameterChecksPassed=true;
assignin('base','MWS',MWS);
fprintf('T700 workspace loaded: %s. No model was modified or simulated.\\n',profile);
end
"""
    (MODEL/'T700_initialize.m').write_text(init,encoding='utf-8')
    for file in setup.glob('*.m'):
        text=file.read_text(encoding='utf-8').replace('% Generated from local Ballin data; see README_T700.txt and build audit.',
          '% Source and approximation notes: results/simsetup_t700/README_current_layout.txt.')
        file.write_text(text,encoding='utf-8')
    after={p.name:digest(p) for p in MODEL.glob('*.mdl')}
    assert before==after
    report=dict(Archive=str(ARCHIVE),ModelHashesUnchanged=before,ModelsEdited=False,
                ActiveInitializer='T700_initialize',AutomaticCheck='T700_check_parameters',
                MATLABRuntimeExecuted=False,OldRebuildScriptsAreHistorical=True)
    out=ROOT/'results'/'simsetup_t700'
    (out/'T700_layout_migration.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
