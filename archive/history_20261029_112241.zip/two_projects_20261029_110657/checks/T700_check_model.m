function report = T700_check_model(mdl,MWS)
% Read-only binding audit of a model already opened by the user.
% Does not load/update/save/simulate a model or initialize workspace parameters.
if nargin<1, mdl='T700_SS'; end
if nargin<2
    assert(evalin('base','exist(''MWS'',''var'')')==1,'Run T700_initialize first.');
    MWS=evalin('base','MWS');
end
mdl=char(string(mdl));
assert(bdIsLoaded(mdl),'Open the intended model manually before checking.');
B={
    'Compressor','Y_C_Map_NcVec_M','MWS.HPC.NcVec'
    'Compressor','X_C_RlineVec_M','MWS.HPC.RlineVec'
    'Compressor','T_C_Map_WcArray_M','MWS.HPC.WcArray'
    'Compressor','T_C_Map_PRArray_M','MWS.HPC.PRArray'
    'Compressor','T_C_Map_EffArray_M','MWS.HPC.EffArray'
    'GGT','Y_T_Map_NcVec_M','MWS.HPT.NcVec'
    'GGT','X_T_Map_PRVec_M','MWS.HPT.PRVec'
    'GGT','T_T_Map_WcArray_M','MWS.HPT.WcArray'
    'GGT','T_T_Map_EffArray_M','MWS.HPT.EffArray'
    'FPT','Y_T_Map_NcVec_M','MWS.FPT.NcVec'
    'FPT','X_T_Map_PRVec_M','MWS.FPT.PRVec'
    'FPT','T_T_Map_WcArray_M','MWS.FPT.WcArray'
    'FPT','T_T_Map_EffArray_M','MWS.FPT.EffArray'
    'Burner','Eff_M','MWS.Burner.Eff'
    'Burner','LHV_M','MWS.Burner.LHV'
    'Burner','dPnormBurner_M','MWS.Burner.dP'
    'BC_T2','Value','MWS.Boundary.T2_R'
    'BC_P2','Value','MWS.Boundary.P2_psia'
    'BC_Wf','Value','MWS.Boundary.Wf'
    'BC_Qload','Value','MWS.Boundary.Qload'
    'BC_P49_Target','Value','MWS.Boundary.P49_psia'};
actual=cell(size(B,1),1); matches=false(size(B,1),1);
for k=1:size(B,1)
    try
        actual{k}=get_param([mdl '/' B{k,1}],B{k,2});
        matches(k)=strcmp(strtrim(actual{k}),B{k,3});
    catch err
        actual{k}=['Unavailable: ' err.message];
    end
end
report.Model=mdl;
report.File=get_param(mdl,'FileName');
report.Profile=MWS.Boundary.Profile;
report.Bindings=cell2table([B,actual,num2cell(matches)], ...
    'VariableNames',{'Block','Parameter','Expected','Actual','Matches'});
report.ListedBindingsMatch=all(matches);
report.PreLoadFcn=get_param(mdl,'PreLoadFcn');
report.InitFcn=get_param(mdl,'InitFcn');
report.ReadOnly=true;
report.CompilationChecked=false;
report.FullTopologyChecked=false;
report.ConvergenceChecked=false;
disp(report.Bindings);
fprintf('Listed bindings match: %d. No model changes, compilation or simulation performed.\n',all(matches));
end
