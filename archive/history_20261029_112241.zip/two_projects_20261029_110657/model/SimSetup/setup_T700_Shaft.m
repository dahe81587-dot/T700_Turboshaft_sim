function MWS = setup_T700_Shaft(MWS)
% Shaft inertia in slug*ft^2; source ft*lbf*s^2 has the same numerical value.
% Source and approximation notes: results/simsetup_t700/README_current_layout.txt.

MWS.Shaft.Jg = 0.044499999999999998;
MWS.Shaft.Jp = 0.062;
MWS.Shaft.Jload = 0; % No external rotor/load inertia has been specified.

end
