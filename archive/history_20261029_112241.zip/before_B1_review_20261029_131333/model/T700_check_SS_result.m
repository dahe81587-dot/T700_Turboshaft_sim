function report = T700_check_SS_result(MWS)
% Check an already completed T700 SS run. No initialization/model changes.
% Uses existing Case02Logs, station and component diagnostic workspace logs.
% Assumes ordinary off-design turbine format, zero inlet FAR and rear GGT cooling.
% Residuals are reconstructed from logged diagnostics, not a direct Mux log.
if nargin<1, MWS=workspaceValue('MWS'); end
logs=workspaceValue('Case02Logs');
solver=logs.getElement('Case02_S').Values;
x=lastValue(logs.getElement('Case02_X').Values); x=x(:);
assert(numel(x)==6,'Expected six SS unknowns.');
stationNames={'s2','s3','s4','s5','s6'};
canonical={'S2','S3','S41','S45','S49'};
stationFields={'W','ht','Tt','Pt','FAR'};
S=struct;
for k=1:5
    raw=workspaceValue(stationNames{k});
    S.(canonical{k})=readScalars(raw,stationFields);
end
assert(abs(S.S2.FAR)<1e-12,'This balance check assumes zero inlet FAR.');
D.Compressor=readScalars(workspaceValue('C_Data'), ...
    {'Wcin','WcMap','s_C_Wc','NcMap','PRMap','Nmech','Wbleeds','Pwrout'});
fields={'Wcs1in','WcMap','s_T_Wc','NcMap','PRMap','Nmech','Pwrout'};
D.GGT=readScalars(workspaceValue('GGT_Data'),fields);
D.FPT=readScalars(workspaceValue('FPT_Data'),fields);
assert(all([D.Compressor.Wcin,D.GGT.Wcs1in,D.FPT.Wcs1in]>0));

report=struct;
report.Profile=MWS.Boundary.Profile;
report.Boundary=MWS.Boundary;
report.X=x;
report.UnknownOrder=MWS.Solve.UnknownOrder;
report.Stations=S;
report.Diagnostics=D;
report.SolverConverged=logical(lastValue(getValue(solver,'Converged')));
report.JacFailed=logical(lastValue(getValue(solver,'JacFailed')));
report.ResidualOrder=MWS.Solve.ResidualOrder;
report.ResidualSource='Reconstructed from logged ordinary T-MATS component diagnostics';
report.InputContextMatches=abs(S.S2.Pt-MWS.Boundary.P2_psia)<1e-7 && ...
    abs(S.S2.Tt-MWS.Boundary.T2_R)<1e-6 && ...
    abs((S.S41.W-S.S3.W)-MWS.Boundary.Wf)<1e-7;

% Constants are from installed constants_TMATS.h / Shaft library.
hpToTorque=5252.113;
accessoryHpToTorque=5252.11;
btuPerSecondToHp=1.414853;
torqueC=hpToTorque*D.Compressor.Pwrout/D.Compressor.Nmech;
torqueG=hpToTorque*D.GGT.Pwrout/D.GGT.Nmech;
torqueF=hpToTorque*D.FPT.Pwrout/D.FPT.Nmech;
netNg=torqueC+torqueG-accessoryHpToTorque*MWS.Boundary.Pacc_g/x(5);
netNp=torqueF-MWS.Boundary.Qload-accessoryHpToTorque*MWS.Boundary.Pacc_p/x(6);
r=[(S.S49.Pt-MWS.Boundary.P49_psia)/MWS.Boundary.P49_psia; ...
    (D.Compressor.Wcin-D.Compressor.WcMap*D.Compressor.s_C_Wc)/D.Compressor.Wcin; ...
    (D.GGT.Wcs1in-D.GGT.WcMap*D.GGT.s_T_Wc)/D.GGT.Wcs1in; ...
    (D.FPT.Wcs1in-D.FPT.WcMap*D.FPT.s_T_Wc)/D.FPT.Wcs1in; ...
    60*netNg/(2*pi*MWS.Shaft.J);60*netNp/(2*pi*MWS.Shaft1.J)];
report.Residual=r;
report.ResidualTolerances=MWS.Solve.C_Lim(:);
report.ResidualsPassed=all(abs(r)<=report.ResidualTolerances);
report.ShaftNetTorque_lbf_ft=[netNg;netNp];

% Check the actual requested map coordinates, not a clamped interpolated value.
coords=[x(2),D.Compressor.NcMap;D.GGT.PRMap,D.GGT.NcMap;D.FPT.PRMap,D.FPT.NcMap];
names={'Compressor','GGT','FPT'};
inRange=false(3,1);
for k=1:3
    C=MWS.(names{k});
    if k==1, axis=C.RlineVec; else, axis=C.PRVec; end
    inRange(k)=coords(k,1)>=min(axis) && coords(k,1)<=max(axis) && ...
        coords(k,2)>=min(C.NcVec) && coords(k,2)<=max(C.NcVec);
    report.MapCoordinates.(names{k})=coords(k,:);
    report.MapLimits.(names{k})=[min(axis),max(axis);min(C.NcVec),max(C.NcVec)];
end
report.MapInputsInRange=inRange;
report.MapRangesPassed=all(inRange);

% Three configured bleeds: two discarded, third returns at GGT outlet.
fractions=MWS.Compressor.BleedFractions(:);
hfractions=MWS.Compressor.BleedEnthalpyFractions(:);
assert(numel(fractions)==3 && numel(hfractions)==3);
bleedW=S.S2.W*fractions;
bleedH=S.S2.ht+hfractions*(S.S3.ht-S.S2.ht);
returnedCooling=S.S45.W-S.S41.W;
report.BleedFlowExpected_lbm_s=bleedW;
report.TotalBleedLogged_lbm_s=D.Compressor.Wbleeds;
report.CoolingReturnLogged_lbm_s=returnedCooling;
report.BleedConfigurationPassed=abs(D.Compressor.Wbleeds-sum(bleedW))<1e-6 && ...
    abs(returnedCooling-bleedW(3))<1e-6;
report.MassError_lbm_s=S.S49.W-(S.S2.W+MWS.Boundary.Wf-sum(bleedW(1:2)));
report.MassTolerance_lbm_s=1e-6;
report.MassBalancePassed=abs(report.MassError_lbm_s)<=report.MassTolerance_lbm_s;

% Steady enthalpy balances [Btu/s]; using logged ht preserves gas-table datum.
heatIn=MWS.Boundary.Wf*MWS.Burner.LHV*MWS.Burner.Eff;
power=[D.Compressor.Pwrout;D.GGT.Pwrout;D.FPT.Pwrout]/btuPerSecondToHp;
energy=[S.S2.W*S.S2.ht-S.S3.W*S.S3.ht-sum(bleedW.*bleedH)-power(1); ...
    S.S3.W*S.S3.ht+heatIn-S.S41.W*S.S41.ht; ...
    S.S41.W*S.S41.ht+bleedW(3)*bleedH(3)-S.S45.W*S.S45.ht-power(2); ...
    S.S45.W*S.S45.ht-S.S49.W*S.S49.ht-power(3)];
scale=[max([abs(S.S2.W*S.S2.ht),abs(S.S3.W*S.S3.ht),abs(power(1)),1]); ...
    max([abs(heatIn),abs(S.S41.W*S.S41.ht),1]); ...
    max([abs(S.S41.W*S.S41.ht),abs(power(2)),1]); ...
    max([abs(S.S45.W*S.S45.ht),abs(power(3)),1])];
report.EnergyComponentOrder={'Compressor','Burner','GGT','FPT'};
report.EnergyError_Btu_s=energy;
report.EnergyRelativeError=energy./scale;
report.EnergyRelativeTolerance=1e-3; % Numerical screening, not experimental accuracy.
report.EnergyBalancePassed=all(abs(report.EnergyRelativeError)<=report.EnergyRelativeTolerance);
report.AllChecksPassed=report.SolverConverged && ~report.JacFailed && ...
    report.InputContextMatches && report.ResidualsPassed && report.MapRangesPassed && ...
    report.BleedConfigurationPassed && report.MassBalancePassed && report.EnergyBalancePassed;
report.ExperimentalValidationPassed=false;
report.DynamicTrimVerified=false;
disp(table(report.ResidualOrder(:),r,report.ResidualTolerances, ...
    abs(r)<=report.ResidualTolerances,'VariableNames',{'Residual','Value','Tolerance','Passed'}));
checks={'InputContextMatches','ResidualsPassed','MapRangesPassed', ...
    'BleedConfigurationPassed','MassBalancePassed','EnergyBalancePassed'};
for k=1:numel(checks), fprintf('%s: %d\n',checks{k},report.(checks{k})); end
fprintf('Mass balance error [lbm/s]: %.6g\n',report.MassError_lbm_s);
outDir=fullfile(MWS.Project.Root,'results','simsetup_t700');
if ~isfolder(outDir), mkdir(outDir); end
save(fullfile(outDir,'T700_SS_result_check.mat'),'report');
report.AllChecksPassed
end

function value=workspaceValue(name)
assert(evalin('base',sprintf('exist(''%s'',''var'')',name))==1, ...
    'Missing %s. Run the intended T700_SS simulation first.',name);
value=evalin('base',name);
end

function result=readScalars(raw,fields)
result=struct;
for k=1:numel(fields)
    value=lastValue(getValue(raw,fields{k}));
    assert(isscalar(value),'Expected scalar diagnostic %s.',fields{k});
    result.(fields{k})=value;
end
end

function value=getValue(raw,name)
assert(isstruct(raw) && isfield(raw,name),'Missing logged field %s.',name);
value=raw.(name);
end

function value=lastValue(raw)
if isa(raw,'timeseries')
    assert(~isempty(raw.Time),'Empty timeseries.');
    value=getdatasamples(raw,numel(raw.Time));
elseif isnumeric(raw) || islogical(raw)
    if isvector(raw), value=raw; else, value=raw(end,:); end
else
    error('Unsupported logged value type: %s.',class(raw));
end
value=double(value(:));
assert(~isempty(value) && all(isfinite(value)),'Empty or nonfinite logged result.');
end
