function MWS = T700_initialize(profile,caseID)
% Unified workspace initialization. Does not open, edit, or run a model.
% T700_initialize                 -> Ballin reference trim 1
% T700_initialize('lewis',4)      -> Lewis experimental input case 4
if nargin<1 || isempty(profile), profile='ballin_trim1'; end
if nargin<2, caseID=[]; end
profile=char(string(profile));
if strcmpi(profile,'lewis')
    validateattributes(caseID,{'numeric'},{'scalar','integer','>=',1,'<=',6});
elseif strcmpi(profile,'ballin_trim1')
    assert(isempty(caseID),'Ballin trim1 does not use a Lewis CaseID. Omit the second argument.');
else
    error('Profile must be ballin_trim1 or lewis.');
end
modelDir=fileparts(mfilename('fullpath'));
projectRoot=fileparts(modelDir);
setupRoot=fullfile(modelDir,'SimSetup_T700');
addpath(modelDir,'-begin');
addpath(setupRoot,'-begin');
dataFile=fullfile(projectRoot,'data_processed','T700_parameter_bundle.mat');
S=load(dataFile,'T700Parameters');
P=S.T700Parameters;
MWS=struct;
MWS.engName='T700_reference_adapter';
MWS.top_level=modelDir;
% Only runtime constants/reference seed and component metadata enter MWS.
% Original source samples and measured experimental outputs stay in the MAT file.
MWS.T700.Constants=P.Constants;
MWS.T700.Reference=P.Reference;
MWS.T700.Compressor.MetadataJSON=P.Compressor.MetadataJSON;
MWS.T700.GGT.MetadataJSON=P.GGT.MetadataJSON;
MWS.T700.FPT.MetadataJSON=P.FPT.MetadataJSON;
MWS.Reference.Source.Report='NASA-TM-83579, Table I';
MWS.Reference.Source.Engine='NASA Lewis experimental test article';
MWS.Reference.Input=array2table(P.Experimental.InputNumeric,'VariableNames', ...
    {'CaseID','P2_psia','T2_R','P49_psia','Qload_lbf_ft','Wf_lb_h'});
MWS.Reference.Input.Wf_lb_s=MWS.Reference.Input.Wf_lb_h/3600;
MWS=setup_T700_Compressor(MWS);
MWS=setup_T700_GGT(MWS);
MWS=setup_T700_FPT(MWS);
MWS=setup_T700_Burner(MWS);
MWS=setup_T700_Shaft(MWS);
MWS=setup_T700_Shaft1(MWS);
MWS=setup_T700_Inlet(MWS);
MWS=setup_T700_Duct(MWS);
MWS=setup_T700_Nozzle(MWS);
MWS=setup_T700_boundary(MWS,profile,caseID);
% Solver settings belong to the initialization entry, not a component file.
MWS.Solve.C_Lim = [1e-6;1e-6;1e-6;1e-6;0.05;0.05];
MWS.Solve.J_Calc_Per = [0.005*ones(1,6);-0.005*ones(1,6)];
MWS.Solve.NR_IC = MWS.T700.Reference.XSeed(:);
MWS.Solve.NR_dx = 5; % Update limit: 5 percent, not an iteration count.
MWS.Solve.NR_Jac_Re = 20;
MWS.Solve.T = 0.015;
ngBounds = MWS.Compressor.s_Nc*[min(MWS.Compressor.NcVec);max(MWS.Compressor.NcVec)]*sqrt(MWS.Boundary.T2_R/MWS.T700.Constants.Tstd);
MWS.Solve.Lower = [1;min(MWS.Compressor.RlineVec);min(MWS.GGT.PRVec);min(MWS.FPT.PRVec);ngBounds(1);5000];
MWS.Solve.Upper = [15;max(MWS.Compressor.RlineVec);max(MWS.GGT.PRVec);max(MWS.FPT.PRVec);ngBounds(2);1.2*MWS.T700.Constants.NpDesign];
MWS.Solve.NR_IC = min(MWS.Solve.Upper,max(MWS.Solve.Lower,MWS.Solve.NR_IC));
MWS.Solve.UnknownOrder = {'W_in','Rline','PR_GGT','PR_FPT','Ng','Np'};
MWS.Solve.ResidualOrder = {'P49_error','Compressor_flow','GGT_flow','FPT_flow','Ng_dot_rpm_s','Np_dot_rpm_s'};


MWS.in.SimTime = 1.5; % Time steps are not an asserted NR iteration count.
MWS.Input.NRICDyn = nan(4,1);
MWS.Input.Ng0 = NaN;
MWS.Input.Np0 = NaN;
MWS.Input.LP_Shaft = NaN;
MWS.Input.FARin = NaN;
MWS.Project.Root = projectRoot;
MWS.Project.SetupRoot = setupRoot;
MWS.Project.ParametersGenerated = true;
MWS.Project.DataPackageLoaded = true;
MWS.Project.MapAdapterLoaded = true;
MWS.Project.T700ParametersApplied = false; % Requires model-interface audit.
MWS.Project.SSInterfacesReady = false;
MWS.Project.SteadyConvergenceVerified = false;
MWS.Project.ExperimentalValidated = false;
MWS.Project.DynamicTrimReady = false;
MWS.Project.NozzleParametersReady = false;
MWS.Project.BleedScheduleMode = 'frozen_AppendixB_trim1';
MWS.Project.MapsAreReferenceConditionApproximation = true;
MWS.Project.AllSourcePhenomenaImplementedExactly = false;

names={'setup_T700_Compressor';'setup_T700_GGT';'setup_T700_FPT'; ...
    'setup_T700_Burner';'setup_T700_Shaft';'setup_T700_Shaft1'; ...
    'setup_T700_Inlet';'setup_T700_Duct';'setup_T700_Nozzle';'setup_T700_boundary'};
files=cell(size(names));
for k=1:numel(names)
    files{k}=which(names{k});
    assert(strcmpi(files{k},fullfile(setupRoot,[names{k} '.m'])),'Wrong setup source: %s',names{k});
end
MWS.Project.SetupFiles=table(names,files,'VariableNames',{'Function','File'});
MWS.Project.ParameterBundle=dataFile;
MWS.Project.ExperimentalMeasurementsLoaded=false;
assert(strcmpi(which('T700_check_parameters'),fullfile(modelDir,'T700_check_parameters.m')));
T700_check_parameters(MWS);
MWS.Project.ParameterChecksPassed=true;
assignin('base','MWS',MWS);
fprintf('T700 workspace loaded: %s. No model was modified or simulated.\n',profile);
end
