function MWS = setup_T700_boundary(MWS,profile,caseID)
% Select boundary data without adapting maps to experimental outputs.
C = MWS.T700.Constants;
if strcmpi(profile,'ballin_trim1')
    MWS.Boundary.P2_psia = C.TrimP2;
    MWS.Boundary.T2_R = C.TrimT2;
    MWS.Boundary.P49_psia = MWS.T700.Reference.P49_psia;
    MWS.Boundary.Wf = C.TrimWf_lbm_h/3600;
    MWS.Boundary.Qload = C.TrimQload;
    MWS.Boundary.CaseID = 0;
    MWS.Boundary.Source = 'Ballin_public_reference_trim1';
elseif strcmpi(profile,'lewis')
    assert(isscalar(caseID) && ismember(caseID,1:6),'CaseID must be 1..6.');
    R = MWS.Reference.Input(MWS.Reference.Input.CaseID==caseID,:);
    MWS.Boundary.P2_psia = R.P2_psia;
    MWS.Boundary.T2_R = R.T2_R;
    MWS.Boundary.P49_psia = R.P49_psia;
    MWS.Boundary.Wf = R.Wf_lb_s;
    MWS.Boundary.Qload = R.Qload_lbf_ft;
    MWS.Boundary.CaseID = caseID;
    MWS.Boundary.Source = 'NASA_Lewis_test_article_unadapted_reference_maps';
else
    error('Profile must be ballin_trim1 or lewis.');
end
MWS.Boundary.FAR2 = 0;
MWS.Boundary.Pacc_g = 0;
MWS.Boundary.Pacc_p = 0;
MWS.Boundary.Alt = 0;
MWS.Boundary.dTamb = 0;
MWS.Boundary.Mach = 0;
MWS.Boundary.Profile = profile;
MWS.Boundary.OutletTotalPressurePrescribed = true;
MWS.Boundary.ExhaustFactorAlsoImposed = false;
end
