当前入口与文件组织（2026-10-29）

model根目录保留两份工程的模型、初始化、绘图及两个SimSetup目录。
SimSetup为原Turboshaft教学模型参数；SimSetup_T700为T700参数，二者不互相调用。
SimSetup_T700按实际模块名包含Compressor/GGT/FPT/Burner/Shaft/Shaft1/Inlet/Duct/Nozzle与边界设置函数。
求解器、路径、必要数据、数据来源记录等由T700_initialize直接设置。
T700初始化唯一入口是T700_initialize。旧入口与模型阶段构建脚本已退役。
历史快照和一次性维护脚本已封存到archive/history_*.zip，不应添加到MATLAB搜索路径。
本轮按用户要求修改两份T700模型的部件参数引用；模型回调、连线、模块和记录方式未改动。

使用：
cd('E:\postgraduate\09_Turboshaft\06_simulink\example\T700_validation\model')
MWS=T700_initialize;                 % Ballin trim1边界
% 或 MWS=T700_initialize('lewis',4); % Lewis第4工况输入
PlotData('maps');                  % 只查看当前参数特性图
% 原Turboshaft工程先运行：MWS=Turboshaft_initialize;
% SS仿真完成后： [fig,R]=PlotData('ss');
% Dyn仿真完成后：[fig,R]=PlotData('dyn',Plant_Data);
% 如使用SimulationOutput：PlotData('ss',out)或PlotData('dyn',out)。
% PlotData兼容两份工程，一次绘制站位、部件特性图与日志中存在的转速/特性图工作点。
% 调用前应确认输入结果与当前MWS来自同一目标工程和工况。

参数检查在初始化末尾自动调用。若检查失败，初始化会报错，新的MWS不会发布到工作区。
T700_check_parameters.m和T700_check_model.m均放在model根目录，初始化不再添加checks路径。
T700_check_model覆盖44项参数表达式，包含部件缩放系数、喘振线、SS求解器初值/边界/容差；最后直接显示report.ListedBindingsMatch。
手动修改MWS后可以再次调用：report=T700_check_parameters(MWS);
手动打开并修改模型后可以调用：report=T700_check_model('T700_SS',MWS);
模型检查仅审查列出的参数绑定并报告回调，不编译、不保存、不修改模型，不代表完整拓扑或收敛通过。
仿真完成后手动调用：SSreport=T700_check_SS_result;
该函数位于model，只读取现有Case02Logs、s2..s6和C_Data/GGT_Data/FPT_Data，复算六残差、图域和守恒，不修改模型或重新初始化。
检查结果保存为results/simsetup_t700/T700_SS_result_check.mat，最后显示AllChecksPassed。
能量相对误差容差1e-3用于数值守恒筛查，不表示实验误差指标；AllChecksPassed也不表示实验验证或动态配平通过。
当前仍无自动仿真或模型构建入口。

注意：初始化会完全重建MWS，不应在需要保留仿真配平结果时重复调用。
默认Ballin不使用Lewis编号，第二参数应省略；Lewis必须明确提供1..6编号。
模型原回调T700_initialize现在会进入统一的新初始化实现，加载的是T700参考参数。
模型实际绑定、引气冷却、边界、动态初值等仍由用户手动修改。
绘图唯一入口为PlotData.m，内部使用局部函数读取两种输出格式、绘图，不增加外部入口。
T700_plot_parameters.m、PlotResults.m、PlotSSData.m已从活动目录移除，原文件封存于archive/plots_before_merge_*.zip。
四个模型绘图按钮的OpenFcn仍引用旧PlotSSData.m，需用户手动改为：
SS按钮：PlotData('ss');
Dyn按钮：PlotData('dyn');
本轮未修改任何模型回调或模型输出配置；修改按钮前请直接在命令窗口调用PlotData。
PlotData只读取已有结果，不运行模型、不修改基础工作区。
稳态图取最后一次求解样本，不代表收敛通过；动态图绘制记录时序。
PlotData统一物理站位S2/S3/S41/S45/S49。原日志s4/S4对应S41，s5/S5对应S45，s6/S6对应S49。
两模型To Workspace均为Timeseries：Dyn还同时记录Plant_Data总线和独立S1..S7；SS记录独立小写s变量。
不必为了画图重接日志总线；若后续手动统一，优先统一物理站位含义、字段、单位及时间记录。

T700_parameter_bundle.mat位于data_processed。当前只将所需常数、参考初值、
部件元数据和实验输入表写入MWS。源曲线和实验测量输出仍在数据文件中，未放入MWS。
SimSetup_T700的特性数组数值未改变，仅将HPC/HPT字段改为Compressor/GGT，双轴Jg/Jp改为Shaft.J/Shaft1.J。
数据包内部对应字段也已重命名，并通过原生MAT接口写入/回读验证。
T700_SS和T700_Dyn每份修改33处参数文本，包含Noz->Nozzle、Burner效率绑定、部件数组和惯量引用。
OPC所有XML部件解析/逐节点比较通过，连线、端口、模块开关和To Workspace记录方式未改变。
原Turboshaft两份模型未改动；GasTurbine_SS_Example_cleanup.m仅用于满足它们原有的CloseFcn引用。
该旧名称并非T700要求；清空原Turboshaft模型CloseFcn后，可删除此路径清理脚本。
Nozzle参数缺少T700几何和气体表：明确设置NaN/空数组，不可直接用于活动喷管计算。
SS喷管已关闭；Dyn喷管仍活动，需用户确定后续排气边界方案。动态配平、引气冷却接入尚未完成。
压气机低压比支路近似、涡轮重复Nc行、参考温度/FAR/引气/压损冻结等限制继续适用。
原构建/复算报告是先前阶段的历史证据，其旧入口路径不再适用于当前目录。
data_processed中的旧stage06d构建脚本不应直接重跑，以免恢复已退役的目录与入口。
详见T700_active_file_audit.json和T700_two_project_migration.json。
MAT文件回读和静态语法检查不等同于MATLAB执行、模型运行、实验验证或动态配平；绘图入口尚待实际输出运行检查。
