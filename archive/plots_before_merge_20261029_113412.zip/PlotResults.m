function [fig,R] = PlotResults(mode,source)
% Station plots for both projects, without changing models or workspace data.
% PlotResults('ss') uses lowercase SS logs in the base workspace.
% PlotResults('dyn',Plant_Data) uses the logged nested bus explicitly.
% PlotResults('dyn',out) / PlotResults('ss',out) accept SimulationOutput/struct.
% A steady plot uses final NR samples; it does not assert steady convergence.
mode=lower(char(string(mode)));
assert(ismember(mode,{'ss','dyn'}),'Mode must be ss or dyn.');
if nargin<2
    source=struct;
    if strcmp(mode,'ss')
        names={'s2','s3','s4','s5','s6','C_Data','GGT_Data','FPT_Data'};
    else
        names={'Plant_Data','S2','S3','S4','S5','S6','CompData','GGTData','FPTData'};
    end
    for k=1:numel(names)
        if evalin('base',sprintf('exist(''%s'',''var'')',names{k}))==1
            source.(names{k})=evalin('base',names{k});
        end
    end
end
if strcmp(mode,'ss')
    stationKeys={'s2','s3','s4','s5','s6'};
    componentKeys={'C_Data','GGT_Data','FPT_Data'};
    stationSource=source; componentSource=source;
    origin='SS individual logs';
else
    plant=getValue(source,'Plant_Data');
    if isempty(plant) && isstruct(source) && isfield(source,'StationData'), plant=source; end
    plant=unwrap(plant);
    if isstruct(plant) && isfield(plant,'StationData')
        stationSource=unwrap(plant.StationData);
        componentSource=getValue(plant,'Data');
        origin='Plant_Data.StationData';
    else
        stationSource=source; componentSource=source;
        origin='Dyn individual uppercase logs';
    end
    stationKeys={'S2','S3','S4','S5','S6'};
    componentKeys={'CompData','GGTData','FPTData'};
end
canonical={'S2','S3','S41','S45','S49'};
locations={'Compressor inlet','Compressor outlet','GGT inlet','FPT inlet','FPT outlet'};
fields={'W','Tt','Pt','FAR'};
units={'lbm/s','degR','psia','-'};
R=struct('Mode',mode,'Source',origin,'ConvergenceChecked',false,'Stations',struct,'Components',struct);
last=nan(5,4);
for k=1:5
    station=unwrap(getValue(stationSource,stationKeys{k}));
    assert(isstruct(station) && isscalar(station), ...
        'Missing gas-station log %s. Supply results from the intended run explicitly.',stationKeys{k});
    for j=1:4
        signal=getValue(station,fields{j});
        assert(~isempty(signal),'Station %s is missing %s.',stationKeys{k},fields{j});
        [t,y,timeKnown]=series(signal);
        R.Stations.(canonical{k}).(fields{j})=struct('Time',t,'Data',y,'TimeKnown',timeKnown);
        last(k,j)=y(end);
    end
end
components={'Compressor','GGT','FPT'};
for k=1:3
    value=getValue(componentSource,componentKeys{k});
    if ~isempty(value), R.Components.(components{k})=value; end
end
R.Mapping=table(canonical(:),stationKeys(:),locations(:), ...
    'VariableNames',{'CanonicalStation','LoggedStation','Location'});
R.LastValues=array2table(last,'VariableNames',fields,'RowNames',canonical);
fig=figure('Name',['Engine results: ' mode]); tiledlayout(2,2);
for j=1:4
    nexttile;
    if strcmp(mode,'ss')
        bar(last(:,j)); xticks(1:5); xticklabels(canonical);
        xlabel('Physical station; final solver sample');
    else
        hold on; allTimed=true;
        for k=1:5
            v=R.Stations.(canonical{k}).(fields{j});
            plot(v.Time,v.Data,'DisplayName',canonical{k});
            allTimed=allTimed && v.TimeKnown;
        end
        if allTimed, xlabel('Time [s]'); else, xlabel('Sample index / supplied time'); end
        legend('Location','best');
    end
    ylabel([fields{j} ' [' units{j} ']']); grid on;
end
disp(R.Mapping); disp(R.LastValues);
end

function value=getValue(source,name)
value=[];
if isa(source,'Simulink.SimulationOutput')
    if any(strcmp(source.who,name)), value=source.get(name); end
elseif isstruct(source) && isscalar(source) && isfield(source,name)
    value=source.(name);
end
end

function value=unwrap(value)
if isa(value,'Simulink.SimulationData.Signal'), value=value.Values; end
if isa(value,'timeseries') && isstruct(value.Data) && isscalar(value.Data)
    value=value.Data;
end
end

function [t,y,timeKnown]=series(value)
value=unwrap(value); timeKnown=true;
if isa(value,'timeseries')
    t=value.Time; y=value.Data;
elseif isstruct(value) && isfield(value,'Time') && isfield(value,'Data')
    t=value.Time; y=value.Data;
elseif isstruct(value) && isfield(value,'time') && isfield(value,'signals')
    t=value.time; y=value.signals.values;
elseif isnumeric(value)
    y=value; t=(0:numel(y)-1)'; timeKnown=false;
else
    error('Unsupported station signal type: %s.',class(value));
end
y=squeeze(y);
assert(isnumeric(y) && isvector(y) && ~isempty(y),'Expected one scalar signal per time sample.');
y=double(y(:)); t=double(t(:));
assert(numel(t)==numel(y),'Signal time and data lengths differ.');
end
