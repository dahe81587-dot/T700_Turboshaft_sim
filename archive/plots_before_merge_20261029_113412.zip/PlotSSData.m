% Shared model plot-button entry. Reads existing logs; does not run a model.
plotModel=bdroot(gcb);
if endsWith(plotModel,'_Dyn')
    PlotResults('dyn');
elseif endsWith(plotModel,'_SS')
    PlotResults('ss');
else
    error('Use PlotResults(''ss'') or PlotResults(''dyn'') explicitly.');
end
clear plotModel
